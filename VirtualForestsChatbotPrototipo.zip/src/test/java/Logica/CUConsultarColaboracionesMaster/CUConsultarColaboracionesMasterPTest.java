/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarColaboracionesMaster;

import Comun.DTO.DTOColaboracion;
import Modelo.CUConsultarColaboracionesMaster.CUModeloConsultarColaboracionesMaster;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.easymock.EasyMock;

import org.easymock.IAnswer;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.anyDouble;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.EasyMock.isA;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import org.easymock.IAnswer;
import static org.junit.Assert.*;
/**
 *
 * @author usuario
 */
public class CUConsultarColaboracionesMasterPTest {
    
    @Mock
    private CUModeloConsultarColaboracionesMaster modelo; 
    @Mock
    private List<DTOColaboracion> listado;
    @Mock
    private DTOColaboracion dto;
    private CUConsultarColaboracionesMasterP presenter;
    
    @Before
    public void setUp() {
        modelo = createMock(CUModeloConsultarColaboracionesMaster.class);
        listado = createMock(ArrayList.class);
        dto = createMock(DTOColaboracion.class);
        presenter = new CUConsultarColaboracionesMasterP(modelo);
    }
    
    
 
    @Test(expected=IllegalArgumentException.class)
    public void testConsultarColaboracionesMasterProgramaNull() {
       presenter.consultarColaboracionesMaster(null);
    }
    @Test
    public void testConsultarColaboracionesMasterPresentacionNull() {
        String programa="Montes";
        expect(modelo.getPresentacionColaboraciones()).andReturn(null).times(1);
        expect(modelo.getPlantillaColaboracion()).andReturn("").times(1);
        expect(modelo.getColaboraciones(programa)).andReturn(listado).times(1);
        replay(modelo);
        assertNull(presenter.consultarColaboracionesMaster(programa));
        
        verify(modelo);
    }
    @Test
    public void testConsultarColaboracionesMasterPlantillaColabNull() {
        String programa="Montes";
        expect(modelo.getPresentacionColaboraciones()).andReturn("").times(1);
        expect(modelo.getPlantillaColaboracion()).andReturn(null).times(1);
        expect(modelo.getColaboraciones(programa)).andReturn(listado).times(1);
        replay(modelo);
        assertNull(presenter.consultarColaboracionesMaster(programa));
        
        verify(modelo);
    }
    @Test
    public void testConsultarColaboracionesMasterColaboracionesNull() {
        String programa="Montes";
        expect(modelo.getPresentacionColaboraciones()).andReturn("").times(1);
        expect(modelo.getPlantillaColaboracion()).andReturn("").times(1);
        expect(modelo.getColaboraciones(programa)).andReturn(null).times(1);
        replay(modelo);
        assertNull(presenter.consultarColaboracionesMaster(programa));
        
        verify(modelo);
    }
    
    @Test
    public void testConsultarColaboracionesMaster() {
        String programa="Montes";
        expect(modelo.getPresentacionColaboraciones()).andReturn("").times(1);
        expect(modelo.getPlantillaColaboracion()).andReturn("").times(1);
        expect(modelo.getColaboraciones(programa)).andReturn(listado).times(1);
        expect(listado.isEmpty()).andReturn(false).times(1);
        expect(listado.size()).andReturn(1).times(2);
        expect(listado.get(0)).andReturn(dto).times(1);
        expect(dto.getDescripcion()).andReturn("").times(1);
        expect(dto.getEntidad()).andReturn("").times(1);
        expect(dto.getPais()).andReturn("").times(1);
        replay(modelo);
        replay(listado);
        replay(dto);
        assertNotNull(presenter.consultarColaboracionesMaster(programa));
        
        verify(modelo);
        verify(listado);
        verify(dto);
    }
    
      @Test
    public void testConsultarColaboracionesNoexistentesMaster() {
        String programa="Montes";
        expect(modelo.getPresentacionColaboraciones()).andReturn("").times(1);
        expect(modelo.getPlantillaColaboracion()).andReturn("").times(1);
        expect(modelo.getColaboraciones(programa)).andReturn(listado).times(1);
        expect(listado.isEmpty()).andReturn(true).times(1);
        expect(modelo.getMensajeColaboracionesNulas()).andReturn("").times(1);
        replay(modelo);
        replay(listado);
        replay(dto);
        assertNotNull(presenter.consultarColaboracionesMaster(programa));
        
        verify(modelo);
        verify(listado);
        verify(dto);
    }
}
