/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarCronogramaMaster;

import Comun.DTO.DTOCurso;
import Modelo.CUConsultarCronogramaMaster.CUConsultarCronogramaMasterM;
import Modelo.CUConsultarCronogramaMaster.CUModeloConsultarCronogramaMaster;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;

/**
 *
 * 
 * @author JAA
 */
public class CUConsultarCronogramaMasterPTest {
    
    @Mock
    private CUModeloConsultarCronogramaMaster modelo;
    @Mock
    private DTOCurso curso;
    @Mock
    private List<DTOCurso> cronograma;
    private CUConsultarCronogramaMasterP presentador;
    
    @Before
    public void setUp() {
        modelo = createMock(CUConsultarCronogramaMasterM.class);
        curso = createMock(DTOCurso.class); 
        cronograma = createMock(ArrayList.class);
        presentador = new CUConsultarCronogramaMasterP(modelo);
    }
    
    
 
    @Test
    public void testConsultaCronogramaMaster() {
         String programa ="Montes";
         expect(modelo.getPresentacionCronogramaMaster()).andReturn("<stub1>:<stub2>").times(1);
         expect(modelo.getCronogramaMaster(programa)).andReturn(cronograma).times(1);
         expect(modelo.getPlantillaCurso()).andReturn("<stub1>,<stub2>,<stub3>,<stub4>,<stub5>").times(1);
         expect(cronograma.size()).andReturn(1).times(3);
         expect(cronograma.get(0)).andReturn(curso).times(1);
         expect(curso.getNumeroCurso()).andReturn(1).times(1);
         expect(curso.getNumMesFin()).andReturn(2).times(1);
         expect(curso.getNumMesInicio()).andReturn(9).times(1);
         expect(curso.getMesInicio()).andReturn("Septiembre").times(1);
         expect(curso.getMesFin()).andReturn("Febrero").times(1);
         expect(curso.getNumeroECTS()).andReturn(33).times(1);
         
         replay(modelo);
         replay(curso);
         replay(cronograma);
         String respuesta = presentador.consultaCronogramaMaster(programa);
         assertTrue(respuesta.contains("Montes:1\n1,5,Septiembre,Febrero,33"));
         verify(modelo);
         verify(curso);
         verify(cronograma);
                
    }
    
}
