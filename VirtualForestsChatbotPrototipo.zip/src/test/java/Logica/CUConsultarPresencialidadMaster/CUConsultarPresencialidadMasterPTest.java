package Logica.CUConsultarPresencialidadMaster; 


import Logica.CUConsultarPresencialidadMaster.CUConsultarPresencialidadMasterP;
import Modelo.CUConsultarPresencialidadMaster.CUModeloConsultarPresencialidadMaster;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;
 
public class CUConsultarPresencialidadMasterPTest {
     
    private CULogicaConsultarPresencialidadMaster presentador;
    @Mock
    private CUModeloConsultarPresencialidadMaster modelo;
    @Before
    public void setUp() {
        modelo = createMock(CUModeloConsultarPresencialidadMaster.class);
        presentador = new CUConsultarPresencialidadMasterP(modelo);
    }
    
    @Test(expected=IllegalArgumentException.class)
    public void testConsultarPresencialidadMasterNullPrograma() {
        presentador.consultarPresencialidadMaster(null);
        
    }
     
    @Test
    public void testConsultarPresencialidadMaster() {
        String programa ="Montes";
        expect(modelo.getExcepcionalidadPresencialidad()).andReturn("").times(1);
        expect(modelo.getPresencialidadMaster(programa)).andReturn("").times(1);
        expect(modelo.getPresentacionPresencialidadMaster()).andReturn("").times(1);
        replay(modelo);
        presentador.consultarPresencialidadMaster(programa);
        verify(modelo);
    }
    
     @Test
    public void testConsultarPresencialidadMasterNullExcepcionalidad() {
        String programa ="Montes";
        expect(modelo.getExcepcionalidadPresencialidad()).andReturn(null).times(1);
        expect(modelo.getPresencialidadMaster(programa)).andReturn("").times(1);
        expect(modelo.getPresentacionPresencialidadMaster()).andReturn("").times(1);
        replay(modelo);
        presentador.consultarPresencialidadMaster(programa);
        verify(modelo);
    }
    
      @Test
    public void testConsultarPresencialidadMasterNullPresencialidad() {
        String programa ="Montes";
        expect(modelo.getExcepcionalidadPresencialidad()).andReturn("").times(1);
        expect(modelo.getPresencialidadMaster(programa)).andReturn(null).times(1);
        expect(modelo.getPresentacionPresencialidadMaster()).andReturn("").times(1);
        replay(modelo);
        presentador.consultarPresencialidadMaster(programa);
        verify(modelo);
    }
    
      @Test
    public void testConsultarPresencialidadMasterNullPresentacionPresencialidad() {
        String programa ="Montes";
        expect(modelo.getExcepcionalidadPresencialidad()).andReturn("").times(1);
        expect(modelo.getPresencialidadMaster(programa)).andReturn("").times(1);
        expect(modelo.getPresentacionPresencialidadMaster()).andReturn(null).times(1);
        replay(modelo);
        presentador.consultarPresencialidadMaster(programa);
        verify(modelo);
    }
    
}
