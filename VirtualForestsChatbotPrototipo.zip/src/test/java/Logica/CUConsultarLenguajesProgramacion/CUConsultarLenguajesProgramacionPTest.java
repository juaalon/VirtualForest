/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarLenguajesProgramacion;

import Comun.DTO.DTOMaster;
import Modelo.CUConsultarLenguajesProgramacion.CUModeloConsultarLenguajesProgramacion;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;

/**
 *
 * @author usuario
 */
public class CUConsultarLenguajesProgramacionPTest {
    
    private CUConsultarLenguajesProgramacionP presentador;
    @Mock
    private CUModeloConsultarLenguajesProgramacion modelo;
     @Mock
     private DTOMaster master;
    
    @Before
    public void setUp() {
        modelo = createMock(CUModeloConsultarLenguajesProgramacion.class);
        master = createMock(DTOMaster.class);
        presentador = new CUConsultarLenguajesProgramacionP(modelo);
    }
      
    @Test
    public void testConsultarRecomendacionLenguajes() {
        String programa="Montes";
        expect(modelo.getPlantillaPresentacionLProg()).andReturn("<stub>").times(1);;
        expect(modelo.getMaster(programa)).andReturn(master).times(1);
        expect(master.getNombre()).andReturn(programa).times(1);
        expect(master.getlProgPrincipal()).andReturn("R").times(1);
        expect(master.getlProgSecundario()).andReturn("Python").times(1);
        expect(modelo.getPlantillaLenguajeProg()).andReturn("<stub1><stub2>").times(1);;
        replay(modelo);
        replay(master);
        presentador.consultarRecomendacionLenguajes(programa);
        verify(modelo);
        verify(master);
    }
    
     @Test(expected=IllegalArgumentException.class)
    public void testConsultarRecomendacionLenguajesNullPrograma() {
        String programa=null;
       
        presentador.consultarRecomendacionLenguajes(programa);
    }
     @Test(expected=IllegalArgumentException.class)
    public void testConsultarRecomendacionLenguajesNullPlantilla() {
        String programa="Montes";
        expect(modelo.getPlantillaPresentacionLProg()).andReturn(null).times(1);
        expect(modelo.getMaster(programa)).andReturn(master).times(1);;
        expect(modelo.getPlantillaLenguajeProg()).andReturn("").times(1);;
        replay(modelo);
        presentador.consultarRecomendacionLenguajes(programa);
        verify(modelo);
    }
     @Test(expected=IllegalArgumentException.class)
    public void testConsultarRecomendacionLenguajesNullMaster() {
        String programa="Montes";
        expect(modelo.getPlantillaPresentacionLProg()).andReturn("").times(1);
        expect(modelo.getMaster(programa)).andReturn(null).times(1);;
        expect(modelo.getPlantillaLenguajeProg()).andReturn("").times(1);;
        replay(modelo);
        presentador.consultarRecomendacionLenguajes(programa);
        verify(modelo);
    }
      @Test(expected=IllegalArgumentException.class)
    public void testConsultarRecomendacionLenguajesNullPlantillaMaster() {
        String programa="Montes";
        expect(modelo.getPlantillaPresentacionLProg()).andReturn("").times(1);
        expect(modelo.getMaster(programa)).andReturn(master).times(1);;
        expect(modelo.getPlantillaLenguajeProg()).andReturn(null).times(1);;
        replay(modelo);
        presentador.consultarRecomendacionLenguajes(programa);
        verify(modelo);
    }
}
