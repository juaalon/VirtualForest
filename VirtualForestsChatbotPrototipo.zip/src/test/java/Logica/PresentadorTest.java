/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Comun.DialogFlowStruct;
import Logica.CUConsultarPresencialidadMaster.CULogicaConsultarPresencialidadMaster;
import Logica.CUConsultarAccesoMaster.CULogicaConsultarAccesoMaster;
import Logica.CUConsultarColaboracionesMaster.CULogicaConsultarColaboracionesMaster;
import Logica.CUConsultarCronogramaMaster.CULogicaConsultarCronogramaMaster;
import Logica.CUConsultarIdiomasMaster.CULogicaConsultarIdiomasMaster;
import Logica.CUConsultarPrecioAproximadoMaster.CULogicaConsultarPrecioAproximadoMaster;
import Logica.CUInformarPlanesMaster.CULogicaInformarPlanesMaster;
import Logica.CUConsultarContenidoMaster.CULogicaConsultarContenidoMaster;
import Logica.CUConsultarLenguajesProgramacion.CULogicaConsultarLenguajesProgramacion;
import Modelo.ModeloDefaultFallback;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.easymock.EasyMock;

import org.easymock.IAnswer;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.anyDouble;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.EasyMock.isA;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import org.easymock.IAnswer;
import static org.junit.Assert.*;


/**
 *
 * @author usuario
 */
public class PresentadorTest {
    
    
    private Presentador control;
    @Mock
    private  CULogicaInformarPlanesMaster controlInformarMaster;
    @Mock
    private  CULogicaConsultarAccesoMaster controlConsultarAccesoMaster;
    @Mock
    private  CULogicaConsultarIdiomasMaster controlConsultarIdiomasMaster;
    @Mock
    private  CULogicaConsultarPrecioAproximadoMaster controlConsultarPrecioMaster;
    @Mock
    private  CULogicaConsultarPresencialidadMaster controlPresencialidadMaster;
    @Mock
    private  CULogicaConsultarCronogramaMaster controlCronogramaMaster;
    @Mock
    private  CULogicaConsultarContenidoMaster controlConsultarMaster;
    @Mock
    private  CULogicaConsultarLenguajesProgramacion controlLenguajesProgramacion;
    @Mock
    private CULogicaConsultarColaboracionesMaster controlColaboracionesMaster;
    @Mock
    private DialogFlowStruct struct;
    @Mock 
    private ModeloDefaultFallback modelo;
    
    @Before
    public void setUp() {
        controlInformarMaster = createMock(CULogicaInformarPlanesMaster.class);
        controlConsultarAccesoMaster = createMock(CULogicaConsultarAccesoMaster.class);
        controlConsultarIdiomasMaster = createMock(CULogicaConsultarIdiomasMaster.class);
        controlConsultarPrecioMaster = createMock(CULogicaConsultarPrecioAproximadoMaster.class);
        controlCronogramaMaster = createMock(CULogicaConsultarCronogramaMaster.class);
        controlConsultarMaster = createMock(CULogicaConsultarContenidoMaster.class);
        controlLenguajesProgramacion = createMock(CULogicaConsultarLenguajesProgramacion.class);
        controlColaboracionesMaster = createMock(CULogicaConsultarColaboracionesMaster.class);
        struct = createMock(DialogFlowStruct.class);
        modelo = createMock(ModeloDefaultFallback.class);
        control = new Presentador();
        control.setControlConsultarAccesoMaster(controlConsultarAccesoMaster);
        control.setControlConsultarIdiomasMaster(controlConsultarIdiomasMaster);
        control.setControlConsultarPrecioMaster(controlConsultarPrecioMaster);
        control.setControlInformarMaster(controlInformarMaster);
        control.setControlPresencialidadMaster(controlPresencialidadMaster);
        control.setControlConsultarMaster(controlConsultarMaster);
        control.setControlCronogramaMaster(controlCronogramaMaster);
        control.setControlConsultarLenguajesProgramacion(controlLenguajesProgramacion);
        control.setControlColaboracionesMaster(controlColaboracionesMaster);
        control.setModeloDefaultFallback(modelo);
    }
    
 
    @Test
    public void testGetResponseFromPresenterListadoMastersNoServicio() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Masteres_Disponibles");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultServiceNotAvailable()).andReturn("no está disponible").times(1);
        expect(controlInformarMaster.getListadoMasteres()).andReturn(null).times(1);
        replay(struct);
        replay(modelo);
        replay(controlInformarMaster);
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("no está disponible"));
        verify(struct);
        verify(modelo);
        verify(controlInformarMaster);
    }
    
    @Test
    public void testGetResponseFromPresenterListadoMasters() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Masteres_Disponibles");
        ArrayList masteres = createMock(ArrayList.class);
          
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
         
        expect(controlInformarMaster.getListadoMasteres()).andReturn(masteres).times(1);
        expect(masteres.size()).andReturn(1).times(2);
        expect(masteres.get(0)).andReturn("Montes").times(1);
        replay(struct);
        replay(masteres);
        replay(controlInformarMaster);
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
 
        assertTrue(response.contains("Montes"));
        verify(struct);
        verify(masteres);
        verify(controlInformarMaster);
    }
    
    
    
    @Test
    public void testGetResponseFromPresenterConsultarAccesoMasterNullPrograma() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Acceso_Master");
        Map mapa2 = new HashMap();
        mapa.put("Master", null);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa2).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("no he entendido").times(1);
        replay(modelo);
        replay(struct);
      
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("no he entendido"));
        verify(struct);
        verify(modelo);
         
    }
    
     @Test
    public void testGetResponseFromPresenterConsultarAccesoMasterEmptyPrograma() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Acceso_Master");
        Map mapa2 = new HashMap();
        mapa.put("Master", "");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa2).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("no he entendido").times(1);
        replay(modelo);
        replay(struct);
      
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("no he entendido"));
        verify(modelo);
        verify(struct);
         
    }
    
     @Test
    public void testGetResponseFromPresenterConsultarAccesoMasterProgramaSinNacionalidadNiTitulo() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Acceso_Master");
        Map mapa2 = createMock(Map.class);
        //mapa.put("Master", "Montes");
        expect(mapa2.get("Master")).andReturn("Montes").times(1);
        expect(mapa2.containsKey("geo-country")).andReturn(false).times(1);
        expect(mapa2.containsKey("AfirmacionNegacion")).andReturn(false).times(1);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa2).times(1);
        expect(controlConsultarAccesoMaster.tratarDialogoAccesoMaster("Montes", null,null)).andReturn("").times(1);
        replay(modelo);
        replay(mapa2);
        replay(struct);
        replay(controlConsultarAccesoMaster);
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        verify(struct);
        verify(mapa2);
        verify(controlConsultarAccesoMaster);
    }
    
     @Test
    public void testGetResponseFromPresenterConsultarAccesoMasterProgramaConNacionalidadSinTitulo() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Acceso_Master");
        Map mapa2 = createMock(Map.class);
        //mapa.put("Master", "Montes");
        expect(mapa2.get("Master")).andReturn("Montes").times(1);
        expect(mapa2.containsKey("geo-country")).andReturn(true).times(1);
        expect(mapa2.get("geo-country")).andReturn("España").times(1);
        expect(mapa2.containsKey("AfirmacionNegacion")).andReturn(false).times(1);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa2).times(1);
        expect(controlConsultarAccesoMaster.tratarDialogoAccesoMaster("Montes","España",null)).andReturn("");
        replay(mapa2);
        replay(struct);
        replay(controlConsultarAccesoMaster);
      
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        verify(struct);
        verify(mapa2);
        verify(controlConsultarAccesoMaster);
    }
    
    
   
    
    @Test
    public void testGetResponseFromPresenterConsultarAccesoMasterDeterminaNacionalidad() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Acceso_Master");
        Map mapa2 = new HashMap();
        mapa2.put("Master", "Montes");
        mapa2.put("geo-country", "España");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa2).times(1);
         
        controlConsultarAccesoMaster.tratarDialogoAccesoMaster("Montes","España",null);
        EasyMock.expectLastCall().andAnswer(new IAnswer<Object>() {
            @Override
            public Object answer() throws Throwable {
                return "";
            }
        });


        replay(struct);
        replay(controlConsultarAccesoMaster);
        
        
        String response  = control.getResponseFromPresenter(struct);
        assertNotNull(response);
       
        verify(struct);
        verify(controlConsultarAccesoMaster);
    }
    
     @Test
    public void testGetResponseFromPresenterConsultarAccesoMasterDeterminaHomologacion() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Acceso_Master");
        Map mapa2 = new HashMap();
        mapa2.put("Master", "Dual");
        mapa2.put("geo-country", "Otra");
        mapa2.put("AfirmacionNegacion", "si");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa2).times(1);
         
       controlConsultarAccesoMaster.tratarDialogoAccesoMaster("Dual","Otra",true);
        EasyMock.expectLastCall().andAnswer(new IAnswer<Object>() {
            @Override
            public Object answer() throws Throwable {
                return "";
            }
        });
        replay(struct);
        replay(controlConsultarAccesoMaster);
        
        
        String response  = control.getResponseFromPresenter(struct);
        assertNotNull(response);
       
        verify(struct);
        verify(controlConsultarAccesoMaster);
    }
     @Test
    public void testGetResponseFromPresenterConsultarAccesoMasterDeterminaGraduado() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Acceso_Master");
        Map mapa2 = new HashMap();
        mapa2.put("Master", "Dual");
        mapa2.put("geo-country", "Otra");
        mapa2.put("AfirmacionNegacion", "si");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa2).times(1);
        
       controlConsultarAccesoMaster.tratarDialogoAccesoMaster("Dual","Otra",true);
        EasyMock.expectLastCall().andAnswer(new IAnswer<Object>() {
            @Override
            public Object answer() throws Throwable {
                return "";
            }
        });
        replay(struct);
        replay(controlConsultarAccesoMaster);
        
        
        String response  = control.getResponseFromPresenter(struct);
        assertNotNull(response);
       
        verify(struct);
        verify(controlConsultarAccesoMaster);
    }
    
      @Test
    public void testGetResponseFromPresenterConsultarIdiomasMaster() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Nivel_Idiomas_Master");
        Map mapa2 = new HashMap();
        mapa2.put("Master", "Montes");
        mapa2.put("language", "Inglés");
        
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa2).times(1);
        
       controlConsultarIdiomasMaster.consultarIdiomasMaster("Montes","Inglés");
        EasyMock.expectLastCall().andAnswer(new IAnswer<Object>() {
            @Override
            public Object answer() throws Throwable {
                return "";
            }
        });
        replay(struct);
        replay(controlConsultarIdiomasMaster);
        
        
        String response  = control.getResponseFromPresenter(struct);
        assertNotNull(response);
       
        verify(struct);
        verify(controlConsultarIdiomasMaster);
    }
    
    
      @Test
    public void testGetResponseFromPresenterConsultarIdiomasMaster2() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Nivel_Idiomas_Master");
        Map mapa2 = new HashMap();
        mapa2.put("Master", "Montes");
        
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa2).times(1);
        
       controlConsultarIdiomasMaster.consultarIdiomasMaster("Montes" );
        EasyMock.expectLastCall().andAnswer(new IAnswer<Object>() {
            @Override
            public Object answer() throws Throwable {
                return "";
            }
        });
        replay(struct);
        replay(controlConsultarIdiomasMaster);
        
        
        String response  = control.getResponseFromPresenter(struct);
        assertNotNull(response);
       
        verify(struct);
        verify(controlConsultarIdiomasMaster);
    }
    @Test
    public void testGetResponseFromPresenterPrecioAproximadoMasterProgramaNull() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Precio_Aproximado_Master");
        mapa.put("Master", null);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("Lo siento").times(1);
        replay(modelo);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Lo siento"));
        verify(modelo);
        verify(struct);
         
    }
    @Test
    public void testGetResponseFromPresenterPrecioAproximadoMasterProgramaEmpty() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Precio_Aproximado_Master");
        mapa.put("Master", "");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("Lo siento").times(1);
        replay(modelo); 
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Lo siento"));
        verify(modelo);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterPrecioAproximadoMasterPrograma() {
        Map mapa = new HashMap();
        String programa = "Montes";
        mapa.put("displayName", "Consultar_Precio_Aproximado_Master");
         mapa.put("Master", programa);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(controlConsultarPrecioMaster.consultarPrecioMaster(programa)).andReturn("").times(1);
        replay(controlConsultarPrecioMaster);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertEquals(response,"");
        verify(controlConsultarPrecioMaster);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterPrecioAproximadoMasterProgramaReturnNull() {
        Map mapa = new HashMap();
        String programa = "Montes";
        mapa.put("displayName", "Consultar_Precio_Aproximado_Master");
         mapa.put("Master", programa);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(controlConsultarPrecioMaster.consultarPrecioMaster(programa)).andReturn(null).times(1);
        expect(modelo.getDefaultServiceNotAvailable()).andReturn("El servicio no está disponible").times(1);
        replay(modelo);
        replay(controlConsultarPrecioMaster);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        
        assertTrue(response.contains("El servicio no está disponible"));
        verify(controlConsultarPrecioMaster);
        verify(struct);
        verify(modelo);
         
    }
    @Test
    public void testGetResponseFromPresenterConsultarMasterProgramaNull() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Solicitar_Resumen_Master");
        mapa.put("Master", null);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("Lo siento").times(1);
        replay(modelo);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Lo siento"));
        verify(modelo);
        verify(struct);
         
    }
    @Test
    public void testGetResponseFromPresenterConsultarMasterProgramaEmpty() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Solicitar_Resumen_Master");
        mapa.put("Master", "");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("Lo siento").times(1);
        replay(modelo);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Lo siento"));
        verify(modelo);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterConsultarMasterPrograma() {
        Map mapa = new HashMap();
        String programa = "Montes";
        mapa.put("displayName", "Solicitar_Resumen_Master");
         mapa.put("Master", programa);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(controlConsultarMaster.getDescripcionMaster(programa)).andReturn("").times(1);
        replay(controlConsultarMaster);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertEquals(response,"");
        verify(controlConsultarMaster);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterConsultarMasterProgramaReturnNull() {
        Map mapa = new HashMap();
        String programa = "Montes";
        mapa.put("displayName", "Solicitar_Resumen_Master");
         mapa.put("Master", programa);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(controlConsultarMaster.getDescripcionMaster(programa)).andReturn(null).times(1);
        replay(controlConsultarMaster);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        
        assertNull(response );
        verify(controlConsultarMaster);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterConsultarCronogramaProgramaNull() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Cronograma_Master");
        mapa.put("Master", null);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("Lo siento").times(1);
        replay(modelo);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Lo siento"));
        verify(modelo);
        verify(struct);
         
    }
    @Test
    public void testGetResponseFromPresenterConsultarCronogramaProgramaEmpty() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Cronograma_Master");
        mapa.put("Master", "");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("Lo siento").times(1);
        replay(modelo); 
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Lo siento"));
        verify(modelo);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterConsultarCronogramaPrograma() {
        Map mapa = new HashMap();
        String programa = "Montes";
        mapa.put("displayName", "Consultar_Cronograma_Master");
         mapa.put("Master", programa);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(controlCronogramaMaster.consultaCronogramaMaster(programa)).andReturn("").times(1);
        replay(controlCronogramaMaster);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertEquals(response,"");
        verify(controlCronogramaMaster);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterConsultarCronogramaReturnNull() {
        Map mapa = new HashMap();
        String programa = "Montes";
        mapa.put("displayName", "Consultar_Cronograma_Master");
         mapa.put("Master", programa);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(controlCronogramaMaster.consultaCronogramaMaster(programa)).andReturn(null).times(1);
        expect(modelo.getDefaultServiceNotAvailable()).andReturn("El servicio no está disponible").times(1);
        replay(modelo);
        replay(controlCronogramaMaster);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        
        assertTrue(response.contains("El servicio no está disponible"));
        verify(controlCronogramaMaster);
        verify(struct);
        verify(modelo);
         
    }
      @Test
    public void testGetResponseFromPresenterConsultarLProgNull() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Lenguaje_Programacion_Master");
        mapa.put("Master", null);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("Lo siento").times(1);
        replay(modelo);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Lo siento"));
        verify(modelo);
        verify(struct);
         
    }
    @Test
    public void testGetResponseFromPresenterConsultarLProgEmpty() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Lenguaje_Programacion_Master");
        mapa.put("Master", "");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("Lo siento").times(1);
        replay(modelo);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Lo siento"));
        verify(modelo);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterConsultarLProg() {
        Map mapa = new HashMap();
        String programa = "Montes";
        mapa.put("displayName", "Consultar_Lenguaje_Programacion_Master");
         mapa.put("Master", programa);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(controlLenguajesProgramacion.consultarRecomendacionLenguajes(programa)).andReturn("").times(1);
        replay(controlLenguajesProgramacion);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertEquals(response,"");
        verify(controlLenguajesProgramacion);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterConsultarLProgReturnNull() {
        Map mapa = new HashMap();
        String programa = "Montes";
        mapa.put("displayName", "Consultar_Lenguaje_Programacion_Master");
         mapa.put("Master", programa);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(controlLenguajesProgramacion.consultarRecomendacionLenguajes(programa)).andReturn(null).times(1);
        expect(modelo.getDefaultServiceNotAvailable()).andReturn("El servicio no está disponible").times(1);
        replay(modelo);
        replay(controlLenguajesProgramacion);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        
        assertTrue(response.contains("El servicio no está disponible"));
        verify(controlLenguajesProgramacion);
        verify(struct);
        verify(modelo);
         
    }
    
      @Test
    public void testGetResponseFromPresenterConsultarColaboracionesNull() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Informacion_Colaboraciones");
        mapa.put("Master", null);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("Lo siento").times(1);
        replay(modelo);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Lo siento"));
        verify(modelo);
        verify(struct);
         
    }
    @Test
    public void testGetResponseFromPresenterConsultarColaboracionesProgEmpty() {
        Map mapa = new HashMap();
        mapa.put("displayName", "Consultar_Informacion_Colaboraciones");
        mapa.put("Master", "");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultMissingMasterInfo()).andReturn("Lo siento").times(1);
        replay(modelo);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Lo siento"));
        verify(modelo);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterConsultarColaboraciones() {
        Map mapa = new HashMap();
        String programa = "Montes";
        mapa.put("displayName", "Consultar_Informacion_Colaboraciones");
         mapa.put("Master", programa);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(controlColaboracionesMaster.consultarColaboracionesMaster(programa)).andReturn("").times(1);
        replay(controlColaboracionesMaster);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertEquals(response,"");
        verify(controlColaboracionesMaster);
        verify(struct);
         
    }
     @Test
    public void testGetResponseFromPresenterConsultarColaboracionesReturnNull() {
        Map mapa = new HashMap();
        String programa = "Montes";
        mapa.put("displayName", "Consultar_Informacion_Colaboraciones");
         mapa.put("Master", programa);
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(controlColaboracionesMaster.consultarColaboracionesMaster(programa)).andReturn(null).times(1);
        expect(modelo.getDefaultServiceNotAvailable()).andReturn("El servicio no está disponible").times(1);
        replay(modelo);
        replay(controlColaboracionesMaster);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        
        assertTrue(response.contains("El servicio no está disponible"));
        verify(controlColaboracionesMaster);
        verify(struct);
        verify(modelo);
         
    }
    @Test
    public void testGetResponseFromPresenterOtherOptions() {
        Map mapa = new HashMap();
        mapa.put("displayName", "");
        expect(struct.getIntent()).andReturn(mapa).times(1);
        expect(struct.getParameters()).andReturn(mapa).times(1);
        expect(modelo.getDefaultIntentFallbackResponse()).andReturn("Mis disculpas").times(1);
        replay(modelo);
        replay(struct);
        
        String response = control.getResponseFromPresenter(struct);
        assertNotNull(response);
        assertTrue(response.contains("Mis disculpas"));
        verify(modelo);
        verify(struct);
         
    }
}
