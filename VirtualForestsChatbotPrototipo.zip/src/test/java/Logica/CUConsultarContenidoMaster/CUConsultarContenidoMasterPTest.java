/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarContenidoMaster;

import Logica.CUConsultarContenidoMaster.CUConsultarContenidoMasterP;
import Modelo.CUConsultarContenidoMaster.CUModeloConsultarContenidoMaster;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;

/**
 *
 * @author usuario
 */
public class CUConsultarContenidoMasterPTest {
    @Mock
    private CUModeloConsultarContenidoMaster modelo;
    private CUConsultarContenidoMasterP presentador;
   
    
    @Before
    public void setUp() {
        modelo = createMock(CUModeloConsultarContenidoMaster.class);
        presentador = new CUConsultarContenidoMasterP(modelo);
    }
      
    @Test
    public void testGetDescripcionMaster() {
        String programa = "Montes";
        expect(modelo.getDescripcionMaster(programa)).andReturn("1").times(1);
        replay(modelo);
        assertEquals(presentador.getDescripcionMaster(programa),"1");
        verify(modelo);
    }
    
}
