/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarIdiomasMaster;

import Comun.DTO.DTOIdioma;
import Modelo.CUConsultarIdiomasMaster.CUConsultarIdiomasMasterM;
import Modelo.CUConsultarIdiomasMaster.CUModeloConsultarIdiomasMaster;
import java.util.ArrayList;
import java.util.List;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import org.easymock.Mock;
 
import org.junit.Before;
 
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author usuario
 */
public class CUConsultarIdiomasMasterPTest {
    @Mock
    private CUModeloConsultarIdiomasMaster modelo;
    @Mock
    private DTOIdioma idioma;
    @Mock
    private List<DTOIdioma> lista; 
    private CUConsultarIdiomasMasterP control;
    
    @Before
    public void setUp() {
        modelo = createMock(CUConsultarIdiomasMasterM.class);
        control = new CUConsultarIdiomasMasterP(modelo);
        lista = createMock(ArrayList.class);
    }
     

    
    @Test(expected=IllegalArgumentException.class)
    public void testConsultarIdiomasMasterIllegalArguments() {
       
        control.consultarIdiomasMaster(null, "");
         
    }
 
     @Test 
    public void testConsultarIdiomasMaster() {
        
        expect(modelo.getRespuestaIdiomasyNivelesMaster("Montes")).andReturn(lista).times(1);
        expect(modelo.getRespuestaIdiomasEncontrados()).andReturn("").times(1);
        expect(modelo.getPlantillaIdioma()).andReturn("").times(1);
        replay(modelo);
        control.consultarIdiomasMaster("Montes");
        verify(modelo);
         
    }
    
    
     @Test 
    public void testConsultarIdiomasMasterIdioma() {
        
        expect(modelo.getRespuestaIdiomaEspecificoyNivelesMaster("Montes","Inglés")).andReturn(lista).times(1);
        expect(modelo.getRespuestaIdiomasEncontrados()).andReturn("").times(1);
        expect(modelo.getPlantillaIdioma()).andReturn("").times(1);
        replay(modelo);
        control.consultarIdiomasMaster("Montes","Inglés");
        verify(modelo);
         
    }
    
}
