/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarECTS;

import Modelo.CUConsultarECTS.CUModeloConsultarECTS;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;
 public class CUConsultarECTSPTest {
    
    private CUConsultarECTSP presenter;
    @Mock
    private CUModeloConsultarECTS modelo;
   
    @Before
    public void setUp() {
        modelo = createMock(CUModeloConsultarECTS.class);
        presenter = new CUConsultarECTSP(modelo);
    }
     
    @Test
    public void testConsultarECTS() {
         expect(modelo.getInfoECTS()).andReturn("");
         replay(modelo);
         presenter.consultarECTS();
         verify(modelo);
    }
    
}
