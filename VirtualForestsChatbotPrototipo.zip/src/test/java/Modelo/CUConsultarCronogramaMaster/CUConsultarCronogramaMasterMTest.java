/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarCronogramaMaster;

import Modelo.CUConsultarCronogramaMaster.CUConsultarCronogramaMasterM;
import Comun.DTO.DTOCurso;
import Persistencia.CUFachadaConsultarCronogramaMaster;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;

/**
 *
 * @author JAA
 */
public class CUConsultarCronogramaMasterMTest {
    @Mock
    private CUFachadaConsultarCronogramaMaster fachada;
    @Mock
    private DTOCurso curso;
    @Mock
    private List<DTOCurso> listadoCursos;
    private CUConsultarCronogramaMasterM modelo;
    
    @Before
    public void setUp() {
        curso = createMock(DTOCurso.class);
        listadoCursos = createMock(ArrayList.class);
        fachada  = createMock(CUFachadaConsultarCronogramaMaster.class);
        modelo = new CUConsultarCronogramaMasterM(fachada);
    }
   
    @Test
    public void testGetPresentacionCronogramaMaster() {
        expect(fachada.getPresentacionCronogramaMaster()).andReturn("stub").times(1);
        replay(fachada);
        assertEquals(modelo.getPresentacionCronogramaMaster(),"stub");
        verify(fachada);
    }

   
    @Test
    public void testGetCronogramaMaster() {
        String programa="Montes";
        expect(fachada.getCursosMaster(programa)).andReturn(listadoCursos).times(1);
        replay(fachada);
        assertEquals(modelo.getCronogramaMaster(programa),listadoCursos);
        verify(fachada);
    }

    
    @Test
    public void testGetPlantillaCurso() {
      
        expect(fachada.getPlantillaCurso()).andReturn("stub").times(1);
        replay(fachada);
        assertEquals(modelo.getPlantillaCurso(),"stub");
        verify(fachada);
    }
    
}
