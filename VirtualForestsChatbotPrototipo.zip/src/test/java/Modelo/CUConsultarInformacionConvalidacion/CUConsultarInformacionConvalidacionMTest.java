/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarInformacionConvalidacion;
import Persistencia.CUFachadaConsultarInformacionConvalidacion;
import java.util.ArrayList;
import java.util.List;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import org.easymock.Mock;
 
import org.junit.Before;
 
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author usuario
 */
public class CUConsultarInformacionConvalidacionMTest {
    @Mock 
    private CUFachadaConsultarInformacionConvalidacion fachada;
    
    private CUConsultarInformacionConvalidacionM modelo;
    
    @Before
    public void setUp() {
        fachada = createMock(CUFachadaConsultarInformacionConvalidacion.class);
        modelo = new CUConsultarInformacionConvalidacionM(fachada);
    }
    
 
    @Test
    public void testConsultarConvalidacion() {
        expect(fachada.getInfoConvalidacion()).andReturn("").times(1);
        replay(fachada);
        modelo.consultarConvalidacion();
        verify(fachada);
    }
    
}
