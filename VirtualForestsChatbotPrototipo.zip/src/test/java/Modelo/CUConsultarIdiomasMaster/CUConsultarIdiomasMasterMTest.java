/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarIdiomasMaster;

import Modelo.CUConsultarIdiomasMaster.CUModeloConsultarIdiomasMaster;
import Modelo.CUConsultarIdiomasMaster.CUConsultarIdiomasMasterM;
import Comun.DTO.DTOIdioma;
import Persistencia.CUFachadaConsultarIdiomasMaster;
import java.util.List;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import org.easymock.Mock;
 
import org.junit.Before;
 
import org.junit.Test;
import static org.junit.Assert.*;
/**
 *
 * @author JAA
 */
public class CUConsultarIdiomasMasterMTest {
    @Mock
    private CUFachadaConsultarIdiomasMaster fachada;
    private CUModeloConsultarIdiomasMaster modelo;
    @Mock
    private DTOIdioma idioma;
    @Mock
    private List<DTOIdioma> lista;
    
    @Before
    public void setUp() {
        fachada = createMock(CUFachadaConsultarIdiomasMaster.class);
        modelo = new CUConsultarIdiomasMasterM(fachada);
    }
      
    @Test
    public void testGetRespuestaIdiomasyNivelesMaster() {
        expect(fachada.getIdiomasDeMaster("Montes")).andReturn(lista);
        replay(fachada);
        modelo.getRespuestaIdiomasyNivelesMaster("Montes");
        verify(fachada);
    }
 
    @Test
    public void testGetRespuestaIdiomaEspecificoyNivelesMaster() {
        expect(fachada.getIdiomasDeMaster("Montes","Inglés")).andReturn(lista);
        replay(fachada);
        modelo.getRespuestaIdiomaEspecificoyNivelesMaster("Montes","Inglés");
        verify(fachada);
    }
 
    @Test
    public void testGetRespuestaIdiomasEncontrados() {
        expect(fachada.getRespuestaIdiomasEncontrados()).andReturn("");
        replay(fachada);
        modelo.getRespuestaIdiomasEncontrados();
        verify(fachada);
    }
 
    @Test
    public void testGetRespuestaIdiomasNoEncontrados() {
        expect(fachada.getRespuestaIdiomasNoEncontrados()).andReturn("");
        replay(fachada);
        modelo.getRespuestaIdiomasNoEncontrados();
        verify(fachada);
    }
 
    @Test
    public void testGetPlantillaIdioma() {
        expect(fachada.getPlantillaIdioma()).andReturn("");
        replay(fachada);
        modelo.getPlantillaIdioma();
        verify(fachada);
    }
    
}
