/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarContenidoMaster;

import Modelo.CUConsultarContenidoMaster.CUConsultarContenidoMasterM;
import Persistencia.CUFachadaConsultarContenidoMaster;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;

/**
 *
 * 
 * @author JAA
 */
public class CUConsultarContenidoMasterMTest {
    @Mock
    private CUFachadaConsultarContenidoMaster fachada;
    private CUConsultarContenidoMasterM modelo;
    @Before
    public void setUp() {
        fachada = createMock(CUFachadaConsultarContenidoMaster.class);
        modelo = new CUConsultarContenidoMasterM(fachada);
    }
    
    @Test
    public void testGetDescripcionMaster() {
       String programa = "Montes";
       expect(fachada.getDescripcionMaster(programa)).andReturn("Montes").times(1);
       replay(fachada);
       modelo.getDescripcionMaster(programa);
       verify(fachada);
    }
    
}
