/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarAccesoMaster;

import Modelo.CUConsultarAccesoMaster.CUConsultarAccesoMasterM;
import Comun.DTO.DTOColaboracion;
import Persistencia.CUFachadaConsultarAccesoMaster;
import Persistencia.FachadaBD;
import java.util.ArrayList;
import java.util.List;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import org.easymock.Mock;
 
import org.junit.Before;
 
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author usuario
 */
public class CUConsultarAccesoMasterMTest {
    
    private CUFachadaConsultarAccesoMaster fachada;
    private CUConsultarAccesoMasterM modelo;
    @Before
    public void setUp() {
        fachada = createMock(FachadaBD.class);
        modelo = new CUConsultarAccesoMasterM(fachada);
    }
     
    @Test
    public void testGetRespuestaSolicitudPais() {
        expect(fachada.getRespuestaSolicitudPaisAccesoMaster()).andReturn("1").times(1);
        replay(fachada);
        modelo.getRespuestaSolicitudPais();
        verify(fachada);
        
    }
 
    @Test
    public void testGetNecesidadHomologacion() {
        expect(fachada.getNecesidadHomologacionMaster("Montes")).andReturn(true).times(1);
        replay(fachada);
        assertTrue(modelo.getNecesidadHomologacion("Montes"));
        verify(fachada);
    }
    
    @Test
    public void testGetNecesidadHomologacionNull() {
        expect(fachada.getNecesidadHomologacionMaster("Montes")).andReturn(null).times(1);
        replay(fachada);
        assertNull(modelo.getNecesidadHomologacion("Montes"));
        verify(fachada);
    }
 
    @Test
    public void testGetRespuestaTituloNecesarioHomologar() {
        expect(fachada.getGraduadoNecesarioHomologar("Montes")).andReturn("1").times(1);
        expect(fachada.getSolicitudGradoHomologado()).andReturn("<stub>").times(1);
        replay(fachada);
        assertTrue((modelo.getRespuestaTituloNecesarioHomologar("Montes")).contains("1"));
        verify(fachada);
    }

    @Test
    public void testGetRespuestaTituloNecesarioHomologarNull() {
        expect(fachada.getGraduadoNecesarioHomologar("Montes")).andReturn(null).times(1);
        expect(fachada.getSolicitudGradoHomologado()).andReturn("<stub>").times(1);
        replay(fachada);
        assertNull((modelo.getRespuestaTituloNecesarioHomologar("Montes")) );
        verify(fachada);
    }
     
    @Test
    public void testGetRespuestaTituloUniversitarioNull() {
        expect(fachada.getGraduadoNecesarioHomologar("Montes")).andReturn("1").times(1);
        expect(fachada.getSolicitudGradoHomologado()).andReturn("<stub>").times(1);
        replay(fachada);
        assertTrue((modelo.getRespuestaTituloNecesarioHomologar("Montes")).contains("1"));
        verify(fachada);
    }
 
    @Test
    public void testGetRespuestaPosesionGraduado() {
        expect(fachada.getGraduadoNecesarioAccesoProgramaMaster("Montes")).andReturn("1").times(1);
        expect(fachada.getPreguntaGradoEspecifico()).andReturn("<stub>").times(1);
        replay(fachada);
        assertTrue((modelo.getRespuestaPosesionGraduado("Montes")).contains("1"));
        verify(fachada);
    }
    
    @Test
    public void testGetRespuestaPosesionGraduadoNull() {
        expect(fachada.getGraduadoNecesarioAccesoProgramaMaster("Montes")).andReturn(null).times(1);
        expect(fachada.getPreguntaGradoEspecifico()).andReturn("<stub>").times(1);
        expect(fachada.getPreguntaGrado()).andReturn("<stub>").times(1);
        replay(fachada);
        assertTrue((modelo.getRespuestaPosesionGraduado("Montes")).contains("<stub>"));
        verify(fachada);
    }
 
    @Test
    public void testGetRequisitoHomologacionAccesoMasterNull() {
       expect(fachada.getNecesidadHomologacionMaster("Montes")).andReturn(null).times(1);
       replay(fachada);
       assertNull(modelo.getRequisitoHomologacionAccesoMaster("Montes"));
       verify(fachada);
       
    }
    
    @Test
    public void testGetRequisitoHomologacionAccesoMaster() {
       expect(fachada.getNecesidadHomologacionMaster("Montes")).andReturn(true).times(1);
       replay(fachada);
       assertTrue(modelo.getRequisitoHomologacionAccesoMaster("Montes"));
       verify(fachada);
       
    }
 
    @Test
    public void testGetRespuestaSolicitudTituloCompatibleHomologado() {
       expect(fachada.getGraduadoNecesarioAccesoProgramaMaster("Montes")).andReturn("M").times(1);
       expect(fachada.getPreguntaGraduadoEspecificoHomologado()).andReturn("<stub>").times(1);
       replay(fachada);
       assertTrue(modelo.getRespuestaSolicitudTituloCompatibleHomologado("Montes").contains("M"));
       verify(fachada);
       
    }
 
    @Test
    public void testGetRespuestaPosesionGraduadoUniversitario() {
       expect(fachada.getPreguntaGrado()).andReturn("M").times(1);
       replay(fachada);
       assertTrue(modelo.getRespuestaPosesionGraduadoUniversitario().contains("M"));
       verify(fachada);
    }
 
    @Test
    public void testGetColaboracionesMaster() {
       expect(fachada.getColaboracionesMaster("Montes")).andReturn(null).times(1);
       replay(fachada);
        modelo.getColaboracionesMaster("Montes") ;
       verify(fachada);
    }
 
    @Test
    public void testGetRespuestaAccesoMaster() {
      expect(fachada.getRespuestaAceptacionMaster()).andReturn("<stub>").times(1);
      replay(fachada);
      assertTrue(modelo.getRespuestaAccesoMaster("Montes").contains("Montes")) ;
      verify(fachada);
    }
 
    @Test
    public void testGetProgramasAlternativos() {
      expect(fachada.getListadoMasteresAlternativos()).andReturn(new ArrayList(0)).times(1);
      replay(fachada);
      modelo.getProgramasAlternativos() ;
      verify(fachada);
    }
 
    @Test
    public void testGetRespuestaNoAccesoMaster() {
      expect(fachada.getRespuestaNoAceptacionMaster()).andReturn("<stub>").times(1);
      replay(fachada);
      assertTrue(modelo.getRespuestaNoAccesoMaster("Montes").contains("Montes")) ;
      verify(fachada);
    }
 
    @Test
    public void testGetRespuestaAccesoMasterNoHomologado() {
        expect(fachada.getRespuestaNoAceptacionMaster()).andReturn("<stub>").times(1);
        expect(fachada.getRespuestaObligacionHomologacion()).andReturn("<stub>").times(1);
        replay(fachada);
        assertTrue(modelo.getRespuestaAccesoMasterNoHomologado("Montes").contains("Montes"));
         verify(fachada);
    }
    
}
