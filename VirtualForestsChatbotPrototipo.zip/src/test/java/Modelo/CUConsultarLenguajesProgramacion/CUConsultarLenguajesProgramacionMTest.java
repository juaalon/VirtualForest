/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarLenguajesProgramacion;

import Comun.DTO.DTOMaster;
import Persistencia.CUFachadaConsultarLenguajesProgramacion;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;

/**
 *
 * @author usuario
 */
public class CUConsultarLenguajesProgramacionMTest {
    @Mock
    private CUFachadaConsultarLenguajesProgramacion fachada;
    private CUConsultarLenguajesProgramacionM modelo;
    
    @Before
    public void setUp() {
        fachada = createMock(CUFachadaConsultarLenguajesProgramacion.class);
        modelo = new CUConsultarLenguajesProgramacionM(fachada);
    }
    
    
 
    @Test
    public void testGetPlantillaPresentacionLProg() {
       expect(fachada.getPlantillaPresLProg()).andReturn("").times(1);
       replay(fachada);
       modelo.getPlantillaPresentacionLProg();
       verify(fachada);
    }

    
    @Test
    public void testGetMaster() {
        String programa="Montes";
       expect(fachada.getMaster(programa)).andReturn(null).times(1);
       replay(fachada);
       modelo.getMaster(programa);
       verify(fachada);
    }
 
    @Test
    public void testGetPlantillaLenguajeProg() {
       
       expect(fachada.getPlantillaLProg()).andReturn("").times(1);
       replay(fachada);
       modelo.getPlantillaLenguajeProg();
       verify(fachada);
    }
    
}
