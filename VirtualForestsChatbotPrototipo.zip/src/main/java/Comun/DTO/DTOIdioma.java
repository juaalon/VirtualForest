/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comun.DTO;

/**
 *
 * @author usuario
 */
public class DTOIdioma {
    private String denominacion;
    private String nivelMinimo;
    private String nivelRecomendado;

    public DTOIdioma(String denominacion, String nivelMinimo, String nivelRecomendado) {
        this.denominacion = denominacion;
        this.nivelMinimo = nivelMinimo;
        this.nivelRecomendado = nivelRecomendado;
    }

    public String getDenominacion() {
        return denominacion;
    }

    public void setDenominacion(String denominacion) {
        this.denominacion = denominacion;
    }

    public String getNivelMinimo() {
        return nivelMinimo;
    }

    public void setNivelMinimo(String nivelMinimo) {
        this.nivelMinimo = nivelMinimo;
    }

    public String getNivelRecomendado() {
        return nivelRecomendado;
    }

    public void setNivelRecomendado(String nivelRecomendado) {
        this.nivelRecomendado = nivelRecomendado;
    }
    
    
}
