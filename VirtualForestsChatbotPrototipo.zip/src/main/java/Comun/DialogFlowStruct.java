
/**
 *
 * @author usuario
 */
package Comun;

import java.util.Map;
 
public class DialogFlowStruct {
    private String responseId;
    private String queryText;
    private Map<String,String> parameters;
    private boolean allRequiredParamsPresent;
    private Map<String,String> intent;
    private double intentDetectionConfidence;
    private String languageCode;
    

    public DialogFlowStruct(String responseId, String queryText, Map<String, String> parameters, boolean allRequiredParamsPresent, Map<String, String> intent, double intentDetectionConfidence, String languageCode) {
        this.responseId = responseId;
        this.queryText = queryText;
        this.parameters = parameters;
        this.allRequiredParamsPresent = allRequiredParamsPresent;
        this.intent = intent;
        this.intentDetectionConfidence = intentDetectionConfidence;
        this.languageCode = languageCode;
         
    }

    public String getResponseId() {
        return responseId;
    }

    public void setResponseId(String responseId) {
        this.responseId = responseId;
    }

    public String getQueryText() {
        return queryText;
    }

    public void setQueryText(String queryText) {
        this.queryText = queryText;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, String> parameters) {
        this.parameters = parameters;
    }

    public boolean isAllRequiredParamsPresent() {
        return allRequiredParamsPresent;
    }

    public void setAllRequiredParamsPresent(boolean allRequiredParamsPresent) {
        this.allRequiredParamsPresent = allRequiredParamsPresent;
    }

    public Map<String, String> getIntent() {
        return intent;
    }

    public void setIntent(Map<String, String> intent) {
        this.intent = intent;
    }

    public double getIntentDetectionConfidence() {
        return intentDetectionConfidence;
    }

    public void setIntentDetectionConfidence(double intentDetectionConfidence) {
        this.intentDetectionConfidence = intentDetectionConfidence;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }
 
 
     
    
}
