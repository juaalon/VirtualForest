 
package Modelo.CUInformarPlanesMaster;

import Comun.DTO.DTOMaster;
import Persistencia.CUFachadaInformarPlanesMaster;
import Persistencia.FachadaBD;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase CUInformarPlanesMasterP, representa a la clase de dominio del CU Informar Planes de Master
 * 
 * @author JAA
 */
public class CUInformarPlanesMasterM implements CUModeloInformarPlanesMaster{
    private CUFachadaInformarPlanesMaster fachada;
    
    /**
     * Constructor de clase.
     * 
     */
    public CUInformarPlanesMasterM (){
        fachada = FachadaBD.getInstancia();
    }
     /**
     * Constructor de clase.
     * 
     * @param f CUFachadaInformarPlanesMaster
     * @throws IllegalArgumentException
     */
    public CUInformarPlanesMasterM (CUFachadaInformarPlanesMaster f) throws IllegalArgumentException{
        if(f==null){
            throw new IllegalArgumentException();
        }else{
            fachada = f;
        }
    }

    /**
     * Metodo requestMasterList, devuelve un listado de másteres disponibles.
     * 
     * @return objeto List con el listado de masteres
     */
    @Override
    public List<DTOMaster> requestMasterList() {
       
        ArrayList<DTOMaster> resultado = null;
        try{
            resultado=(ArrayList<DTOMaster>) fachada.requestMasterList();
             
        }catch(NullPointerException e){
            resultado = null;
        }
        return resultado;
    }
}
