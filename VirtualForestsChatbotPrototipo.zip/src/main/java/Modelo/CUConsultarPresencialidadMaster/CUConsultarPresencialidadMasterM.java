/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarPresencialidadMaster;

import Persistencia.CUFachadaConsultarPresencialidadMaster;
import Persistencia.FachadaBD;

/**
 * Clase CUConsultarPresencialidadMasterM, implementa el modelo del CU Consultar 
 * Presencialidad Master.
 * 
 * @author JAA
 */
public class CUConsultarPresencialidadMasterM implements CUModeloConsultarPresencialidadMaster{

    private CUFachadaConsultarPresencialidadMaster fachada;
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarPresencialidadMasterM(){
        this.fachada = FachadaBD.getInstancia();
    }
    
    public CUConsultarPresencialidadMasterM(CUFachadaConsultarPresencialidadMaster f){
        this.fachada = f;
    }
    /**
     * Metodo getPresentacionPresencialidadMaster, obtiene la presentacion de la
     * modalidad de presencialidad del master.
     * 
     * @return  String con la frase
     */
    @Override
    public String getPresentacionPresencialidadMaster() {
      return fachada.getPresentacionPresencialidadMaster();
    }

    /**
     * Metodo getPresencialidadMaster, obtiene la modalidad de presencialidad del
     * master.
     * 
     * @param programa String programa de master por el que se consulta
     * @return  String con la respuesta
     */
    @Override
    public String getPresencialidadMaster(String programa) {
      return fachada.getPresencialidadMaster(programa);  
    }

    /**
     * Metodo getExcepcionalidadPresencialidad, obtiene la explciacion de negociabilidad
     * de la presencialidad del programa de master.
     * 
     * @return String con la frase
     */
    @Override
    public String getExcepcionalidadPresencialidad() {
      return fachada.getExcepcionalidadPresencialidadMaster();
    }
    
}
