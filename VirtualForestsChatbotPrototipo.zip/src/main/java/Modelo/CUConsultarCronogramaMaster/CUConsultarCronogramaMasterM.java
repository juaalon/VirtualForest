/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarCronogramaMaster;

import Comun.DTO.DTOCurso;
import Persistencia.CUFachadaConsultarCronogramaMaster;
import Persistencia.FachadaBD;
import java.util.List;

/**
 * Clase CUConsultarCronogramaMasterM, modelo del CU Consultar Cronograma Master.
 * 
 * @author JAA
 */
public class CUConsultarCronogramaMasterM implements CUModeloConsultarCronogramaMaster{

    private CUFachadaConsultarCronogramaMaster fachada;
    
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarCronogramaMasterM(){
        fachada = FachadaBD.getInstancia();
    }
    
    public CUConsultarCronogramaMasterM (CUFachadaConsultarCronogramaMaster f){
        this.fachada=f;
    }
    
    @Override
    public String getPresentacionCronogramaMaster() {
        return fachada.getPresentacionCronogramaMaster();
    }

    @Override
    public List<DTOCurso> getCronogramaMaster(String programa) {
        return fachada.getCursosMaster(programa);
    }

    @Override
    public String getPlantillaCurso() {
        return fachada.getPlantillaCurso();
    }
    
}
