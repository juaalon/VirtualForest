/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarAccesoMaster;

import Comun.DTO.DTOColaboracion;
import java.util.List;

/**
 * Interfaz CUPersistenciaConsultarAccesoMaster, implementa la persistencia del 
 * CU Consultar Acceso a un Master.
 * 
 * @author JAA
 */
public interface CUModeloConsultarAccesoMaster {
  

    public String getRespuestaSolicitudPais();

    
    public Boolean getNecesidadHomologacion(String programa);
    
     
    public String getRespuestaTituloNecesarioHomologar(String programa);

    public String getRespuestaTituloUniversitario();

    public String getRespuestaPosesionGraduado(String programa );

    public Boolean getRequisitoHomologacionAccesoMaster(String programa);

    public String getRespuestaSolicitudTituloCompatibleHomologado(String programa);

    public String getRespuestaPosesionGraduadoUniversitario();

    public List<DTOColaboracion> getColaboracionesMaster(String programa);

    public String getRespuestaAccesoMaster(String programa);

    public List<String> getProgramasAlternativos();

    public String getRespuestaNoAccesoMaster(String programa);
 
    public String getRespuestaAccesoMasterNoHomologado(String programa);

    public String getRespuestaPresentacionColaboraciones();
}
