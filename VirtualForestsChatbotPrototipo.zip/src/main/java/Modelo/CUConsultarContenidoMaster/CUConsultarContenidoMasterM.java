/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarContenidoMaster;

import Persistencia.CUFachadaConsultarContenidoMaster;
import Persistencia.FachadaBD;

/**
 * Clase CUConsultarContenidoMasterM, implementa el modelo del CU Consultar Contenido Master.
 * 
 * @author JAA
 */
public class CUConsultarContenidoMasterM implements CUModeloConsultarContenidoMaster{

    private CUFachadaConsultarContenidoMaster fachada;
    
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarContenidoMasterM(){
        fachada =  FachadaBD.getInstancia();
    }
    
    public CUConsultarContenidoMasterM(CUFachadaConsultarContenidoMaster f){
        fachada =  f;
    }
    /**
     * Metodo getDescripcionMaster, devuelve la descripcion del contenido asociado
     * a la imparticion de un master.
     * 
     * @param programa El programa de master
     * @return String con la descripcion
     */
    @Override
    public String getDescripcionMaster(String programa) {
         return fachada.getDescripcionMaster(programa);
    }
    
}
