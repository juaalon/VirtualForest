/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarInformacionConvalidacion;

import Persistencia.CUFachadaConsultarInformacionConvalidacion;
import Persistencia.FachadaBD;

/**
 * Clase CUConsultarInformacionConvalidacionM, implementa el modelo del CU
 * Consultar Informacion Convalidacion.
 * 
 * @author JAA
 */
public class CUConsultarInformacionConvalidacionM implements CUModeloConsultarInformacionConvalidacion{
    private CUFachadaConsultarInformacionConvalidacion fachada;
    
    /**
     * Constructor clase.
     * 
     */
    public CUConsultarInformacionConvalidacionM(){
        fachada = FachadaBD.getInstancia();
    }
    
    public CUConsultarInformacionConvalidacionM(CUFachadaConsultarInformacionConvalidacion f){
        fachada = f;
    }

    /**
     * Metodo consultarConvalidacion, consulta la inforamcion de convalidacion.
     * 
     * @return String
     */
    @Override
    public String consultarConvalidacion() {
         return fachada.getInfoConvalidacion();
    }
    
}
