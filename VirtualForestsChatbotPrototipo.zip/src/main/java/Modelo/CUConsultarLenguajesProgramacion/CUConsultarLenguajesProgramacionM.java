/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarLenguajesProgramacion;

import Comun.DTO.DTOMaster;
import Persistencia.CUFachadaConsultarLenguajesProgramacion;
import Persistencia.FachadaBD;

/**
 * Clase CUConsultarLenguajesProgramacionM, implementa el modelo del CU Consultar 
 * Lenguajes Programacion.
 * 
 * @author JAA
 */
public class CUConsultarLenguajesProgramacionM implements CUModeloConsultarLenguajesProgramacion{

    private CUFachadaConsultarLenguajesProgramacion fachada;
    
    public CUConsultarLenguajesProgramacionM(){
        fachada = FachadaBD.getInstancia();
    }
    
     public CUConsultarLenguajesProgramacionM(CUFachadaConsultarLenguajesProgramacion f){
        fachada = f;
    }
    /**
     * Metodo getPlantillaPresentacionLProg, devuelve la plantilla de presentacion
     * de lenguajes de programacion asociados a un master.
     * 
     * @return String con la plantilla
     */
    @Override
    public String getPlantillaPresentacionLProg() {
        return fachada.getPlantillaPresLProg();
    }

    /**
     * Metodo getMaster, devuelve la informacion referida a un master.
     * 
     * @param programa String con el programa de master por el que se consulta
     * @return DTOMaster
     */
    @Override
    public DTOMaster getMaster(String programa) {
        return fachada.getMaster(programa);
    }

    /**
     * Metodo getPlantillaLenguajeProg, devuelve la plantilla de lenguajes de programacion.
     * 
     * @return String con la plantilla
     */
    @Override
    public String getPlantillaLenguajeProg() {
         return fachada.getPlantillaLProg();
    }

    /**
     * Metodo getRespuestaNoHayLProg, devuelde la respeusta a no hay lenguajes
     * de programacion asociados al master.
     * 
     * @return String
     */
    @Override
    public String getRespuestaNoHayLProg() {
        return fachada.getRespuestaNoHayLProg();
    }
    
}
