/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarCorreoCoordinadorMaster;

import Modelo.CUConsultarCorreoCoordinadorMaster.CUConsultarCorreoCoordinadorMasterM;
import Modelo.CUConsultarCorreoCoordinadorMaster.CUModeloConsultarCorreoCoordinadorMaster;

/**
 *
 * @author usuario
 */
public class CUConsultarCorreoCoordinadorMasterP implements CULogicaConsultarCorreoCoordinadorMaster {

    private CUModeloConsultarCorreoCoordinadorMaster modelo;
    
    public CUConsultarCorreoCoordinadorMasterP(){
        modelo = new CUConsultarCorreoCoordinadorMasterM();
    }
    
    public CUConsultarCorreoCoordinadorMasterP(CUModeloConsultarCorreoCoordinadorMaster m){
        modelo = m;
    }
    
    @Override
    public String consultarCorreoCoordinacionMaster(String programa) {
        String c1 = modelo.getPresentacionCoordinacion();
        String c2 = modelo.consultarCorreoCoordinacionMaster(programa);
        if(c1==null||c2==null){
            return null;
        }else{
            String mensj = c1.replace("<stub>", programa) + c2;
            return mensj;
        }
    }
    
}
