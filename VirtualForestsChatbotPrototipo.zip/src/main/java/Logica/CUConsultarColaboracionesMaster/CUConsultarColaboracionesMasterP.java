/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarColaboracionesMaster;

import Comun.DTO.DTOColaboracion;
import Modelo.CUConsultarColaboracionesMaster.CUConsultarColaboracionesMasterM;
import Modelo.CUConsultarColaboracionesMaster.CUModeloConsultarColaboracionesMaster;
import java.util.List;

/**
 * Clase CUConsultarColaboracionesMasterP, implementa el CU Consultar Colaboraciones Master.
 * 
 * @author JAA
 */
public class CUConsultarColaboracionesMasterP implements CULogicaConsultarColaboracionesMaster {
    
    private CUModeloConsultarColaboracionesMaster modelo;
    
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarColaboracionesMasterP(){
        modelo = new CUConsultarColaboracionesMasterM();
    }
    
    public CUConsultarColaboracionesMasterP(CUModeloConsultarColaboracionesMaster m){
        modelo = m;
    }
    /**
     * Metodo consultarColaboracionesMaster, devuelve la explicacion de colaboraciones de un master.
     * 
     * @param programa String con el programa de master por el que se consulta
     * @return String con la explicacion
     */
    @Override
    public String consultarColaboracionesMaster(String programa) {
       String respuesta;
       String presentacionColaboraciones;
       String plantilla;
       List<DTOColaboracion> colaboraciones;
       if(programa == null){
           throw new IllegalArgumentException();
       }else{
           presentacionColaboraciones = modelo.getPresentacionColaboraciones();
           colaboraciones = modelo.getColaboraciones(programa);
           plantilla = modelo.getPlantillaColaboracion();
            
           if(presentacionColaboraciones==null || colaboraciones==null||plantilla==null){
                respuesta = null;
           }else{
               if(!colaboraciones.isEmpty()){
                   respuesta = presentacionColaboraciones.replace("<stub>",programa);
                   for(int i=0;i<colaboraciones.size();i++){
                       DTOColaboracion dto = colaboraciones.get(i);
                       respuesta = respuesta+"\n"+((plantilla.replace("<stub1>",dto.getEntidad())).replace("<stub2>",dto.getPais())).replace("<stub3>",dto.getDescripcion());
                   }
               }else{
                   respuesta = modelo.getMensajeColaboracionesNulas().replace("<stub>",programa);
               }
           }
       }
       return respuesta;
    }
    
}
