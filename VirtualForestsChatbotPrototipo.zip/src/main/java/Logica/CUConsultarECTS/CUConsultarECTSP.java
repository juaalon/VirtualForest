/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarECTS;

import Modelo.CUConsultarECTS.CUConsultarECTSM;
import Modelo.CUConsultarECTS.CUModeloConsultarECTS;

/**
 * Clase CUConsultarECTSP, implementa la logica del CU Consultar ECTS.
 * 
 * @author JAA
 */
public class CUConsultarECTSP implements CULogicaConsultarECTS{
    private CUModeloConsultarECTS modelo;
    /**
     * Cosntructor de clase.
     * 
     */
    public CUConsultarECTSP(){
        modelo = new CUConsultarECTSM();
    }
    
    public CUConsultarECTSP(CUModeloConsultarECTS m){
        modelo = m;
    }
    /**
     * Metodo consultarECTS, obtiene la inforamción de credito ECTS.
     * 
     * @return String
     */
    @Override
    public String consultarECTS() {
         return modelo.getInfoECTS();
    }
}
