/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUInformarPlanesMaster;

import Comun.DTO.DTOMaster;
import java.util.List;

/**
 *
 * @author usuario
 */
public interface CULogicaInformarPlanesMaster {
    
    public  List<String> getListadoMasteres();
    
}
