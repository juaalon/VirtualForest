/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarCronogramaMaster;

import Comun.DTO.DTOCurso;
import Modelo.CUConsultarCronogramaMaster.CUConsultarCronogramaMasterM;
import Modelo.CUConsultarCronogramaMaster.CUModeloConsultarCronogramaMaster;
import java.util.List;

/**
 * Clase CUConsultarCronogramaMasterP, implementa la logica del CU Consultar Cronograma de Master.
 * 
 * @author JAA
 */
public class CUConsultarCronogramaMasterP implements CULogicaConsultarCronogramaMaster{

    private CUModeloConsultarCronogramaMaster modelo;
    
    /**
     * Constructor de clase.
     */
    public CUConsultarCronogramaMasterP(){
        modelo = new CUConsultarCronogramaMasterM();
    }
    
    public CUConsultarCronogramaMasterP(CUModeloConsultarCronogramaMaster m){
        modelo = m;
    }
    
    /**
     * Metodo consultaCronogramaMaster, realiza la consulta del cronograma de master.
     * 
     * @param programa String con el programa de master
     * @return String con la explicacion del cronograma
     */
    @Override
    public String consultaCronogramaMaster(String programa) {
        String presentacionCronogramaMaster = modelo.getPresentacionCronogramaMaster();
        List<DTOCurso> cronograma = modelo.getCronogramaMaster(programa);
        String plantillaCurso = modelo.getPlantillaCurso();
        String respuesta = obtenResumenCronograma(programa,presentacionCronogramaMaster,cronograma,plantillaCurso);
        return respuesta;   
         
}

    private String obtenResumenCronograma(String programa, String presentacionCronogramaMaster, List<DTOCurso> cronograma, String plantillaCurso) {
        String respuesta= null ; 
         if(presentacionCronogramaMaster!=null&&cronograma!=null&&plantillaCurso!=null){
            
            int numeroCursos=0;
            respuesta =  presentacionCronogramaMaster.replace("<stub1>", programa);
            numeroCursos = obtenNumeroCursos(cronograma);
            respuesta =  respuesta.replace("<stub2>", numeroCursos+"");
            for(int i=0;i<cronograma.size();i++){
                respuesta = respuesta + "\n" + plantillaCurso;
                DTOCurso curso = cronograma.get(i);
                int numeroCurso = curso.getNumeroCurso();
                int numeroMesesCurso = obtenNumeroMesesCurso(curso.getNumMesFin(),curso.getNumMesInicio());
                String mesInicio = curso.getMesInicio();
                String mesFin = curso.getMesFin();
                int numeroECTSCurso = curso.getNumeroECTS();
                respuesta = respuesta.replace("<stub1>", numeroCurso+"");
                respuesta = respuesta.replace("<stub2>", numeroMesesCurso+"");
                respuesta = respuesta.replace("<stub3>", mesInicio);
                respuesta = respuesta.replace("<stub4>", mesFin);
                respuesta = respuesta.replace("<stub5>", numeroECTSCurso+"");
            } 
        }
        return respuesta;
    }
    private int obtenNumeroCursos(List<DTOCurso> cronograma) {
        return cronograma.size();
    }

    private int obtenNumeroMesesCurso(int numMesFin, int numMesInicio) {
       
        return ((12-numMesInicio)+numMesFin);
        
    }
    
}
