/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarPrecioAproximadoMaster;

import Modelo.CUConsultarPrecioAproximadoMaster.CUConsultarPrecioAproximadoMasterM;
import Modelo.CUConsultarPrecioAproximadoMaster.CUModeloConsultarPrecioAproximadoMaster;

/**
 * Clase CUConsultarPrecioAproximadoMasterP, implementa la logica del CU Consultar
 * Precio Aproximado Master.
 * 
 * @author JAA
 */
public class CUConsultarPrecioAproximadoMasterP implements CULogicaConsultarPrecioAproximadoMaster{
    private CUModeloConsultarPrecioAproximadoMaster modelo;
    
    /**
     * Constructor clase.
     * 
     */
    public CUConsultarPrecioAproximadoMasterP(){
        this.modelo = new CUConsultarPrecioAproximadoMasterM();
    }
    
    public CUConsultarPrecioAproximadoMasterP(CUModeloConsultarPrecioAproximadoMaster m){
        this.modelo = m;
    }

    /**
     * Metodo consultarPrecioMaster consulta el precio orientativo del amster para el proximo año.
     * 
     * @param programa String programa de master
     * @return String con la respuesta
     */
    @Override
    public String consultarPrecioMaster(String programa) {
        if(programa==null){
            throw new IllegalArgumentException();
        }else{
            int precioAproximado = modelo.consultarprecioAproximado(programa);
            String presentacionPrecio = modelo.getPresentacionPrecioAproximado();
            String response="";
            if(precioAproximado!= 0 && presentacionPrecio!= null ){
                response = presentacionPrecio.replace("<stub1>",programa).replace("<stub2>",precioAproximado+"");
            }else{
                response = null;
            }
            return response;
        }
    }
}
