/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarLenguajesProgramacion;

import Comun.DTO.DTOMaster;
import Modelo.CUConsultarLenguajesProgramacion.CUConsultarLenguajesProgramacionM;
import Modelo.CUConsultarLenguajesProgramacion.CUModeloConsultarLenguajesProgramacion;

/**
 * Clase CUConsultarLenguajesProgramacionP, implementa la logica del CU Consultar
 * Lenguajes Programacion.
 * 
 * @author JAA
 */
public class CUConsultarLenguajesProgramacionP implements CULogicaConsultarLenguajesProgramacion {

    private CUModeloConsultarLenguajesProgramacion modelo;
    
    public CUConsultarLenguajesProgramacionP(){
        modelo = new CUConsultarLenguajesProgramacionM();
    }
    
    public CUConsultarLenguajesProgramacionP(CUModeloConsultarLenguajesProgramacion m){
        modelo = m;
    }
    
    /**
     * Metodo consultarRecomendacionLenguajes, devuelve las recomendaciones de lengujaes
     * de programacion para un master.
     * 
     * @param programa String con el programa de master
     * @return String con las recomendaciones
     */
    @Override
    public String consultarRecomendacionLenguajes(String programa) {
        if(programa==null){
            throw new IllegalArgumentException();
        }else {
         String mensajePresentacionLenguajes=modelo.getPlantillaPresentacionLProg();
         DTOMaster master=modelo.getMaster(programa);
         String plantillaLenguaje=modelo.getPlantillaLenguajeProg();
         
         String respuesta = ensamblaRespuesta(mensajePresentacionLenguajes,master,plantillaLenguaje);
         return respuesta;
        }
    }

    private String ensamblaRespuesta(String mensajePresentacionLenguajes, DTOMaster master, String plantillaLenguaje) {
         if(mensajePresentacionLenguajes==null||master==null||plantillaLenguaje==null){
             throw new IllegalArgumentException();
         }else{
             String programa = master.getNombre();
             String progPrincipal = master.getlProgPrincipal();
             String progSecundario = master.getlProgSecundario();
             String mensaje = null;
             if(progPrincipal!=null){
  
                mensaje = mensajePresentacionLenguajes.replace("<stub>",programa)+"\n";
                if(progPrincipal!=null&&progSecundario!=null){
                mensaje = mensaje + plantillaLenguaje.replace("<stub1>",progPrincipal).replace("<stub2>",progSecundario);
                }else{
                mensaje = mensaje + plantillaLenguaje.replace("<stub1>",progPrincipal).replace("<stub2>","").replace(progPrincipal+",",progPrincipal);

                }
             }else{
                 mensaje = modelo.getRespuestaNoHayLProg();
             }
             return mensaje;
             
         }
    }
    
}
