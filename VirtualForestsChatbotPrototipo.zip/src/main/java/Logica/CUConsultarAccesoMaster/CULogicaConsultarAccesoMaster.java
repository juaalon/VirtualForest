 
package Logica.CUConsultarAccesoMaster;

/**
 * Interfaz CULogicaConsultarAccesoMaster para la implementacion del CU Consultar
 * Acceso a un Master
 * 
 * @author JAA
 */
public interface CULogicaConsultarAccesoMaster {
  
     
    public String tratarDialogoAccesoMaster(String programa,String nacionalidad,Boolean posesionTitulo);
}
