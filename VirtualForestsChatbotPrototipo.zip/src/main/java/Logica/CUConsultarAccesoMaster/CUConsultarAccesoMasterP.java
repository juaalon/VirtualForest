 
package Logica.CUConsultarAccesoMaster;

import Comun.DTO.DTOColaboracion;
import Modelo.CUConsultarAccesoMaster.CUConsultarAccesoMasterM;
import Modelo.CUConsultarAccesoMaster.CUModeloConsultarAccesoMaster;
import java.util.ArrayList;

/**
 * Clase CUConsultarAccesoMasterP para la implementacion del CU Consultar
 * Acceso a un Master
 *        
 * @author JAA
 */
public class CUConsultarAccesoMasterP implements CULogicaConsultarAccesoMaster  {

    private CUModeloConsultarAccesoMaster modelo;
    
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarAccesoMasterP(){
        modelo = new CUConsultarAccesoMasterM();
    }
   
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarAccesoMasterP(CUModeloConsultarAccesoMaster model){
        modelo = model;
    }
    
     /**
     * Metodo tratarDialogoAccesoMaster, determina el metodo de acceso del estudiante
     * a los programas de Master y la respuesta correspondiente a ese metodo.
     * 
     * @param programa  String con el programa al que acceder
     * @param pais  String con la pais del aspirante
     * @param posesionTitulo Boolean con la informacion de posesion de titulo
     * @throws IllegalArgumentException si el programa es null
     * @return String on la respuesta correspondiente
     */
    @Override
    public String tratarDialogoAccesoMaster(String programa, String pais, Boolean posesionTitulo) throws IllegalArgumentException{
        String respuesta = "";
        if( programa==null){
            throw new IllegalArgumentException();
        }
        if(programa!=null&&pais==null&&posesionTitulo==null){
            respuesta = consultarPosibilidadAcceso(programa);
        }else{
            if(programa!=null&&pais!=null&&posesionTitulo==null){
              
                if(pais.equals("España")){
                        respuesta = consultarPosesionGraduado(programa);
                }else{
                    try{
                        boolean requiereHomologacion = consultarPosibilidadAccesoHomologacion(programa);
                        if(requiereHomologacion){
                            respuesta = obtenerPreguntaPosesionTituloHomologado(programa);
                        }else{
                            respuesta = obtenerPreguntaPosesionGraduadoUniversitario(); 
                        }
                    }catch(IllegalArgumentException iaexcp){
                        return null;
                    }
                }
            }else{
                 if(programa!=null&&pais!=null&&posesionTitulo!=null){
                     respuesta = validarAccesoUsuario(programa,pais,posesionTitulo);
                 }else{ 
                     throw new IllegalArgumentException();
                 }
            
            }
        }
        return respuesta;
    }
    
    
    /**
     * Metodo obtenerPreguntaPosesionTituloHomologado, obtiene dado un programa de master
     * la pregunta a formular al usuario si posee el titulo que da acceso al programa de master
     * homologado.
     * 
     * @param programa String con el programa de master
     * @return String con la pregunta a formular al usuario
     */
    
    private String obtenerPreguntaPosesionTituloHomologado(String programa){
        String respuesta = "";
        respuesta = modelo.getRespuestaSolicitudTituloCompatibleHomologado(programa);
           
        return respuesta;
    }

    /**
     * Metodo obtenerPreguntaPosesionGraduadoUniversitario, obtiene la pregunta para el usuario
     * de si posee el graduado universitario válido para el acceso.
     * 
     * @return String con la pregunta a formular al usuario
     */
    
    private String obtenerPreguntaPosesionGraduadoUniversitario() {
        String respuesta = "";
        respuesta = modelo.getRespuestaPosesionGraduadoUniversitario();
           
        return respuesta;
    }
    
    
    /**
     * Metodo validarAccesoUsuario, valida dadas las condicioens presentadas si el usuario puede
     * acceder al programa de master indicado.
     * 
     * @param programa
     * @param pais
     * @param posesionTitulo 
     * @throws IllegalArgumentException si alguno de los argumentos es null
     * @return String con la respuesta a dar al usuario
     */
    private String validarAccesoUsuario(String programa, String pais, Boolean posesionTitulo) {
        if(programa==null||pais==null||posesionTitulo==null){
            throw new IllegalArgumentException();
        }else{    
            String respuestaFinal = "";
            boolean poseeTitulo = posesionTitulo ;
            if(pais.equals("España")){
                if(!poseeTitulo){
                    String respuestaProgramasAlternativos = getProgramasMasterAlternativos();
                    String respuestaNoAccesoMaster = modelo.getRespuestaNoAccesoMaster(programa);
                    respuestaFinal = respuestaNoAccesoMaster+"\n"+respuestaProgramasAlternativos;
                }else{
                    String respuestaAccesoMaster = modelo.getRespuestaAccesoMaster(programa);
                    respuestaFinal = respuestaAccesoMaster;
                    
                }

            }else{
               boolean requiereHomologacion = modelo.getRequisitoHomologacionAccesoMaster(programa) ;
               if(requiereHomologacion){
                   if(poseeTitulo){
                        ArrayList<DTOColaboracion> respuestaColaboraciones = (ArrayList<DTOColaboracion>) modelo.getColaboracionesMaster(programa);
                        String respuestaAccesoMaster = modelo.getRespuestaAccesoMaster(programa);
                         if(respuestaColaboraciones!=null){
                            respuestaAccesoMaster = respuestaAccesoMaster+"\n"+modelo.getRespuestaPresentacionColaboraciones();

                            respuestaFinal = respuestaAccesoMaster+"\n"+obtenerEntidadesColaboradoras(respuestaColaboraciones);
                        }else{
                            respuestaFinal = respuestaAccesoMaster;
                        }
                   }else{
                        String respuestaProgramasAlternativos = getProgramasMasterAlternativos();
                        String respuestaNoAccesoMaster = modelo.getRespuestaAccesoMasterNoHomologado(programa);
                        respuestaFinal = respuestaNoAccesoMaster+"\n"+respuestaProgramasAlternativos;
                   }
               }else{
                   if(posesionTitulo){
                        ArrayList<DTOColaboracion> respuestaColaboraciones = (ArrayList<DTOColaboracion>) modelo.getColaboracionesMaster(programa);
                        String respuestaAccesoMaster = modelo.getRespuestaAccesoMaster(programa);
                        if(respuestaColaboraciones!=null){
                            respuestaAccesoMaster = respuestaAccesoMaster+"\n"+modelo.getRespuestaPresentacionColaboraciones();

                            respuestaFinal = respuestaAccesoMaster+"\n"+obtenerEntidadesColaboradoras(respuestaColaboraciones);
                        }else{
                            respuestaFinal = respuestaAccesoMaster;
                        }
                   }else{
                         
                        String respuestaAccesoMaster = modelo.getRespuestaNoAccesoMaster(programa);
                        respuestaFinal = respuestaAccesoMaster;
                   }
               }
            }
            return respuestaFinal;
        }
    }
    
    
    /**
     * Metodo consultarPosibilidadAcceso, lleva a cabo la consulta de si el acceso 
     * a un master especifico es posible.
     * 
     * @param programa  String con el programa de Master al que acceder
     * @return String con la respuesta de la evaluacion
     */
    
    private String consultarPosibilidadAcceso(String programa) {
        String respuesta = "";
        respuesta = modelo.getRespuestaSolicitudPais().replace("<stub>",programa);
           
        return respuesta;
    }
    
     /**
     * Metodo consultarPosesionGraduado, lleva a cabo la consulta de si el acceso 
     * a un master especifico es posible dado el pais de la entidad expedidora del
     * titulo y programa de master especifico.
     * 
     * @param programa  String con el programa de Master al que acceder
     * @return String con la respuesta de la solicitud
     */
     
    private String consultarPosesionGraduado(String programa) {
        String respuesta = modelo.getRespuestaPosesionGraduado(programa );
        return respuesta;
    }
    
    /**
     * Metodo consultarPosibilidadAccesoHomologacion, lleva a cabo la consulta de si el acceso 
     * a un master especifico requiere una homologacion del titulo que da acceso previo a su inscripción.
     * 
     * @param programa  String con el programa de Master al que acceder
     * @throws IllegalArguemntException si el resultado de la consulta es null
     * @return boolean con la respuesta de la evaluacion
     */
    
    private boolean consultarPosibilidadAccesoHomologacion(String programa ) throws IllegalArgumentException {
        Boolean respuesta = modelo.getRequisitoHomologacionAccesoMaster(programa) ;
        if(respuesta==null){
            throw new IllegalArgumentException();
        }else{
            return respuesta;
        }
    }

    private String obtenerEntidadesColaboradoras(ArrayList<DTOColaboracion> respuestaColaboraciones) {
        
        String entidades="";
         
            for(int i =0 ; i<respuestaColaboraciones.size();i++){
                entidades = entidades + "\n" +respuestaColaboraciones.get(i).getEntidad();
            }
        
        return entidades;
    }
 
    private String getProgramasMasterAlternativos(){
        ArrayList<String> listado = (ArrayList<String>) modelo.getProgramasAlternativos();
        String programas="";
        for(int i =0; i<listado.size();i++){
            programas = programas + "\n" +listado.get(i);
        }
        return programas;
    }
   

    
}
