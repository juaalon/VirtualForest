/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarInformacionConvalidacion;

import Modelo.CUConsultarInformacionConvalidacion.CUConsultarInformacionConvalidacionM;
import Modelo.CUConsultarInformacionConvalidacion.CUModeloConsultarInformacionConvalidacion;

/**
 * Clase CUConsultarInformacionConvalidacionP, impelemnta la logica del CU Consultar
 * Informacion Convalidacion.
 * 
 * 
 * @author JAA
 */
public class CUConsultarInformacionConvalidacionP implements CULogicaConsultarInformacionConvalidacion{

    private CUModeloConsultarInformacionConvalidacion modelo;
    
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarInformacionConvalidacionP(){
        modelo = new CUConsultarInformacionConvalidacionM();
    }
    
    public CUConsultarInformacionConvalidacionP(CUModeloConsultarInformacionConvalidacion m){
        modelo = m;
    }
    
    /**
     * Metodo consultarProcesoConvalidacion, consulta la informacion relativa al
     * proceso de convalidacion.
     * 
     * @return String
     */
    @Override
    public String consultarProcesoConvalidacion() {
        return modelo.consultarConvalidacion();
    }
    
}
