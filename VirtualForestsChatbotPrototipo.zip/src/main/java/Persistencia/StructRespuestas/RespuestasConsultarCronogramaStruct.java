/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.StructRespuestas;

/**
 *
 * @author JAA
 */
public class RespuestasConsultarCronogramaStruct {
    private String presentacionCronograma;
    private String plantillaCurso;

    public RespuestasConsultarCronogramaStruct(String presentacionCronograma, String plantillaCurso) {
        this.presentacionCronograma = presentacionCronograma;
        this.plantillaCurso = plantillaCurso;
    }

    public String getPresentacionCronograma() {
        return presentacionCronograma;
    }

    public void setPresentacionCronograma(String presentacionCronograma) {
        this.presentacionCronograma = presentacionCronograma;
    }

    public String getPlantillaCurso() {
        return plantillaCurso;
    }

    public void setPlantillaCurso(String plantillaCurso) {
        this.plantillaCurso = plantillaCurso;
    }
    
    
    
}
