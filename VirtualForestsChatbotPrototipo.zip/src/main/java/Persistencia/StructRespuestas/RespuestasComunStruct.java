/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.StructRespuestas;

/**
 *
 * @author usuario
 */
public class RespuestasComunStruct {
    private String defaultFallbackIntent;
    private String defaultFallbackNoService;
    private String defaultFallbackMissingMaster;

    public RespuestasComunStruct(String defaultFallbackIntent, String defaultFallbackNoService, String defaultFallbackMissingMaster) {
        this.defaultFallbackIntent = defaultFallbackIntent;
        this.defaultFallbackNoService = defaultFallbackNoService;
        this.defaultFallbackMissingMaster = defaultFallbackMissingMaster;
    }

    public String getDefaultFallbackIntent() {
        return defaultFallbackIntent;
    }

    public void setDefaultFallbackIntent(String defaultFallbackIntent) {
        this.defaultFallbackIntent = defaultFallbackIntent;
    }

    public String getDefaultFallbackNoService() {
        return defaultFallbackNoService;
    }

    public void setDefaultFallbackNoService(String defaultFallbackNoService) {
        this.defaultFallbackNoService = defaultFallbackNoService;
    }

    public String getDefaultFallbackMissingMaster() {
        return defaultFallbackMissingMaster;
    }

    public void setDefaultFallbackMissingMaster(String defaultFallbackMissingMaster) {
        this.defaultFallbackMissingMaster = defaultFallbackMissingMaster;
    }

     
    
    
}
