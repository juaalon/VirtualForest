/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.StructRespuestas;

/**
 *
 * @author usuario
 */
public class RespuestasPrecioMasterStruct {
    private String presentacionPrecioMaster;

    public RespuestasPrecioMasterStruct(String presentacionPrecioMaster) {
        this.presentacionPrecioMaster = presentacionPrecioMaster;
    }

    public String getPresentacionPrecioMaster() {
        return presentacionPrecioMaster;
    }

    public void setPresentacionPrecioMaster(String presentacionPrecioMaster) {
        this.presentacionPrecioMaster = presentacionPrecioMaster;
    }
    
}
