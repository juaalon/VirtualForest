/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.StructRespuestas;

/**
 *
 * @author usuario
 */
public class RespuestasAccesoMasterStruct {
    private String urlPreinscripcion;
    private String urlHomologacion;
    private String preguntaGradoGeneral;
    private String preguntaGradoEspecifica;
    private String preguntaHomologacionTitulo;
    private String solicitarPaisEntidadExpedidora;
    private String respuestaAceptacionAcceso;
    private String respuestaNegacionAcceso;
    private String respuestaHomologacion;
    private String posibilidadInscripcion;

    public RespuestasAccesoMasterStruct(String urlPreinscripcion, String urlHomologacion, String preguntaGradoGeneral, String preguntaGradoEspecifica, String preguntaHomologacionTitulo, String solicitarPaisEntidadExpedidora, String respuestaAceptacionAcceso, String respuestaNegacionAcceso, String respuestaHomologacion, String posibilidadInscripcion) {
        this.urlPreinscripcion = urlPreinscripcion;
        this.urlHomologacion = urlHomologacion;
        this.preguntaGradoGeneral = preguntaGradoGeneral;
        this.preguntaGradoEspecifica = preguntaGradoEspecifica;
        this.preguntaHomologacionTitulo = preguntaHomologacionTitulo;
        this.solicitarPaisEntidadExpedidora = solicitarPaisEntidadExpedidora;
        this.respuestaAceptacionAcceso = respuestaAceptacionAcceso;
        this.respuestaNegacionAcceso = respuestaNegacionAcceso;
        this.respuestaHomologacion = respuestaHomologacion;
        this.posibilidadInscripcion = posibilidadInscripcion;
    }

    public String getUrlPreinscripcion() {
        return urlPreinscripcion;
    }

    public void setUrlPreinscripcion(String urlPreinscripcion) {
        this.urlPreinscripcion = urlPreinscripcion;
    }

    public String getUrlHomologacion() {
        return urlHomologacion;
    }

    public void setUrlHomologacion(String urlHomologacion) {
        this.urlHomologacion = urlHomologacion;
    }

    public String getPreguntaGradoGeneral() {
        return preguntaGradoGeneral;
    }

    public void setPreguntaGradoGeneral(String preguntaGradoGeneral) {
        this.preguntaGradoGeneral = preguntaGradoGeneral;
    }

    public String getPreguntaGradoEspecifica() {
        return preguntaGradoEspecifica;
    }

    public void setPreguntaGradoEspecifica(String preguntaGradoEspecifica) {
        this.preguntaGradoEspecifica = preguntaGradoEspecifica;
    }

    public String getPreguntaHomologacionTitulo() {
        return preguntaHomologacionTitulo;
    }

    public void setPreguntaHomologacionTitulo(String preguntaHomologacionTitulo) {
        this.preguntaHomologacionTitulo = preguntaHomologacionTitulo;
    }

    public String getSolicitarPaisEntidadExpedidora() {
        return solicitarPaisEntidadExpedidora;
    }

    public void setSolicitarPaisEntidadExpedidora(String solicitarPaisEntidadExpedidora) {
        this.solicitarPaisEntidadExpedidora = solicitarPaisEntidadExpedidora;
    }

    public String getRespuestaAceptacionAcceso() {
        return respuestaAceptacionAcceso;
    }

    public void setRespuestaAceptacionAcceso(String respuestaAceptacionAcceso) {
        this.respuestaAceptacionAcceso = respuestaAceptacionAcceso;
    }

    public String getRespuestaNegacionAcceso() {
        return respuestaNegacionAcceso;
    }

    public void setRespuestaNegacionAcceso(String respuestaNegacionAcceso) {
        this.respuestaNegacionAcceso = respuestaNegacionAcceso;
    }

    public String getRespuestaHomologacion() {
        return respuestaHomologacion;
    }

    public void setRespuestaHomologacion(String respuestaHomologacion) {
        this.respuestaHomologacion = respuestaHomologacion;
    }

    public String getPosibilidadInscripcion() {
        return posibilidadInscripcion;
    }

    public void setPosibilidadInscripcion(String posibilidadInscripcion) {
        this.posibilidadInscripcion = posibilidadInscripcion;
    }
    
    
}
