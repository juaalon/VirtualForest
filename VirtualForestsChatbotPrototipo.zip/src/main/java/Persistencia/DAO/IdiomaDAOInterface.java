/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.DAO;

import Comun.DTO.DTOIdioma;

/**
 *
 * @author JAA
 */
public interface IdiomaDAOInterface extends DAOInterface<DTOIdioma> {
    public String getRespuestaMasteresEncontrados();
    public String getRespuestaMasteresNoEncontrados();
     public String getPlantillaIdioma();
}
