/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.DAO;

import Comun.DTO.DTOColaboracion;
import java.util.List;

/**
 *
 * @author JAA
 */
public interface ColaboracionDAOInterface extends DAOInterface<DTOColaboracion> {
    public  List<DTOColaboracion> getColaboracionesDeUnMaster(String programa);

    public String getPresentacionColaboracionesMaster();

    public String getPlantillaColaboracion();

    public String getMensajeNoColaboracion();

    public String getPresentacionColaboracionesAparte();
    
 
}
