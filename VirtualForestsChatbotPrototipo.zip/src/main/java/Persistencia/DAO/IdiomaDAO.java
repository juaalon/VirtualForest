/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.DAO;

import Persistencia.StructRespuestas.RespuestasIdiomasMasterStruct;
import Comun.DTO.DTOIdioma;
import Persistencia.ConnectionPool;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

/**
 * Clase IdiomaDAO implementa el DAO de los datos asociados a un idioma.
 * 
 * @author JAA
 */
public class IdiomaDAO implements IdiomaDAOInterface{

    private  ConnectionPool pool;
    private  Connection conn;
    private  Gson gson;
    private String lang;
   
    public IdiomaDAO(ConnectionPool pool,Connection conn){
        this.pool = pool;
        this.conn = conn;   
        this.gson = new Gson();
       
    }
     @Override
    public void setLang(String lang){
        this.lang=lang;
    }
    
    @Override
    public DTOIdioma get(Object idioma) {
          
        String query = "SELECT   I.DESIGNACION, I.NIVELMINIMO, I.NIVELRECOMENDADO\n"
        + "FROM  IDIOMA AS I WHERE  I.DESIGNACION LIKE ?\n";
        DTOIdioma lang = null;
        try{
            PreparedStatement statement;
            statement= conn.prepareStatement(query);
            statement.setString(1, (String)idioma);
            ResultSet set = statement.executeQuery();
            
            while(set.next()){
                lang = new DTOIdioma(set.getString("DESIGNACION"),set.getString("NIVELMINIMO"),set.getString("NIVELRECOMENDADO"));
                
            } 
        }catch(Exception e){
           lang = null;
        }
        return lang;
    }
     private RespuestasIdiomasMasterStruct getReader() throws IOException{
         String filePath = "/"+lang+"/RespuestasIdiomasMaster.json";
         ClassLoader classloader = Thread.currentThread().getContextClassLoader();
         Reader reader =   new InputStreamReader(classloader.getResourceAsStream(filePath));
        
         return gson.fromJson(reader, RespuestasIdiomasMasterStruct.class );
    }

     @Override
    public String getRespuestaMasteresEncontrados() {
         String respuesta = null;
        try{
           
            RespuestasIdiomasMasterStruct objectRequest = getReader();
            respuesta = objectRequest.getQueryIdiomas();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return respuesta;
    }
    
     @Override
    public String getPlantillaIdioma() {
         String respuesta = null;
        try{
           
            RespuestasIdiomasMasterStruct objectRequest = getReader();
            respuesta = objectRequest.getPlantillaIdioma();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return respuesta;
    }

    @Override
    public String getRespuestaMasteresNoEncontrados() {
        String respuesta = null;
        try{
           
            RespuestasIdiomasMasterStruct objectRequest = getReader();
            respuesta = objectRequest.getQueryNoIdiomas();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return respuesta;
    } 
     
    @Override
    public List<DTOIdioma> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void save(DTOIdioma t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(DTOIdioma t, String[] params) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(DTOIdioma t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
 
    
}
