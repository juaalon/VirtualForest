/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.DAO;

import Comun.DTO.DTOColaboracion;
import Persistencia.ConnectionPool;
import Persistencia.StructRespuestas.RespuestasConsultarColaboracionStruct;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author usuario
 */
public class ColaboracionDAO implements ColaboracionDAOInterface{
    private  ConnectionPool pool;
    private  Connection conn;
    private Gson gson;
    private String lang;
    
    public ColaboracionDAO(ConnectionPool pool,Connection conn){
        this.pool = pool;
        this.conn = conn;   
        this.gson = new Gson();
    }
     @Override
    public void setLang(String lang){
        this.lang=lang;
    }
    
    private RespuestasConsultarColaboracionStruct getReader() throws IOException{
         String filePath = "/"+lang+"/RespuestaColaboracionMaster.json";
         ClassLoader classloader = Thread.currentThread().getContextClassLoader();
         Reader reader =   new InputStreamReader(classloader.getResourceAsStream(filePath)); 
         return gson.fromJson(reader, RespuestasConsultarColaboracionStruct.class );
    }
    

    @Override
    public DTOColaboracion get(Object ente) {
        throw new UnsupportedOperationException("Not supported yet.");  
    }

    @Override
    public List<DTOColaboracion> getAll() {
        String query = "SELECT ENTIDAD,PAIS,NOMBRE,COLABORACION.DESCRIPCION "
                 + "FROM  MASTERES,  COLABORACION "
                 + "WHERE COLABORACION.IDMASTER = MASTERES.ID";
 
        String entidad = null;
        String pais = null;
        String descripcion = null;
        DTOColaboracion  c = null;
        ArrayList<DTOColaboracion> resultado = null;
        try{
            PreparedStatement statement;
            statement= conn.prepareStatement(query);
             
            ResultSet set = statement.executeQuery();
            resultado = new ArrayList();
            while(set.next()){
                entidad = set.getString("ENTIDAD");    
                pais = set.getString("PAIS");
                descripcion = set.getString("DESCRIPCION");
                c = new DTOColaboracion(entidad,pais,descripcion);
                resultado.add(c);
            }
            
        }catch(Exception e){
           entidad = null;
           pais = null;
        }
         return resultado;
    }

    @Override
    public void save(DTOColaboracion t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(DTOColaboracion t, String[] params) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(DTOColaboracion t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<DTOColaboracion> getColaboracionesDeUnMaster(String programa) {
         String query = "SELECT ENTIDAD,PAIS,NOMBRE, COLABORACION.DESCRIPCION "
                 + "FROM  MASTERES,  COLABORACION "
                 + "WHERE COLABORACION.IDMASTER = MASTERES.ID AND MASTERES.NOMBRE LIKE ?";
 
        String entidad = null;
        String pais = null;
        String descripcion = null;
        DTOColaboracion  c = null;
        ArrayList<DTOColaboracion> resultado = null;
        
        try{
            PreparedStatement statement;
            statement= conn.prepareStatement(query);
            statement.setString(1, programa);
            ResultSet set = statement.executeQuery();
            resultado = new ArrayList();
             
            while(set.next()){
                entidad = set.getString("ENTIDAD");    
                pais = set.getString("PAIS");
                descripcion = set.getString("DESCRIPCION");
                c = new DTOColaboracion(entidad,pais,descripcion);
                resultado.add(c);
            }
             
        }catch(Exception e){
           entidad = null;
           pais = null;
           e.printStackTrace();
        }
         return resultado;
    }

    @Override
    public String getPresentacionColaboracionesMaster() {
        String respuesta = null;
       try{
        respuesta = getReader().getPlantillaPresentacion();
       }catch(Exception excpt){
        excpt.printStackTrace();
       }
       return respuesta;
    }
     @Override
    public String getPresentacionColaboracionesAparte() {
        String respuesta = null;
       try{
        respuesta = getReader().getPresentacionAparte();
       }catch(Exception excpt){
        excpt.printStackTrace();
       }
       return respuesta;
    }

    @Override
    public String getPlantillaColaboracion() {
        String respuesta = null;
       try{
        respuesta = getReader().getPlantillaColaboracion();
       }catch(Exception excpt){
        excpt.printStackTrace();
       }
       return respuesta;
    }

    @Override
    public String getMensajeNoColaboracion() {
      String respuesta = null;
       try{
        respuesta = getReader().getNoHayColaboracion();
       }catch(Exception excpt){
        excpt.printStackTrace();
       }
       return respuesta;
    }

   
}
