/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.DAO;

import Persistencia.ConnectionPool;
import Persistencia.StructRespuestas.RespuestasECTSStruct;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Connection;
import java.util.List;

/**
 *
 * @author usuario
 */
public class ECTSDAO implements ECTSDAOInterface{
 private  ConnectionPool pool;
    private  Connection conn;
    private  Gson gson;
    private String lang;
   
    public ECTSDAO(ConnectionPool pool,Connection conn){
        this.pool = pool;
        this.conn = conn;   
        this.gson = new Gson();
       
    }
     @Override
    public void setLang(String lang){
        this.lang=lang;
    }
    
     private RespuestasECTSStruct getReaderECTSMaster() throws IOException{
         String filePath = "/"+lang+"/RespuestasECTSMaster.json";
         ClassLoader classloader = Thread.currentThread().getContextClassLoader();
         Reader reader =   new InputStreamReader(classloader.getResourceAsStream(filePath));
         
         return gson.fromJson(reader, RespuestasECTSStruct.class );
    }
     
    @Override
    public Object get(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void save(Object t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Object t, String[] params) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getDescripcionCreditoECTS() {
        String resp=null;
        try{
         resp = getReaderECTSMaster().getDescripcion();
        }catch(Exception sql){
            sql.printStackTrace();
        }
        return resp;
    }
    
}
