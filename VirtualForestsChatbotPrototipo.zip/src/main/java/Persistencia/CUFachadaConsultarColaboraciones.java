/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Comun.DTO.DTOColaboracion;
import java.util.List;

/**
 *
 * @author usuario
 */
public interface CUFachadaConsultarColaboraciones {
    List<DTOColaboracion>getColaboracionesMaster(String programa);

    public String getPresentacionColaboraciones();

    public String getPlantillaColaboracion();

    public String getMensajeNoHayColaboraciones();
}
