/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import Comun.DialogFlowStruct;
import Logica.Presentador;
import Persistencia.FachadaBD;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Map;
import java.util.stream.Collectors;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


 
 
/**
 * Clase VirtualForestMainServlet, representa al servlet de contacto del backend del chatbot.
 * 
 * @author JAA
 */
@WebServlet(urlPatterns = {"/VirtualForestMainServlet"})
public class VirtualForestMainServlet extends HttpServlet {
 
    private static Presentador logica;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        String dialogflowQuery = request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
        String respuesta="";
         
       
        try{
            String jsonFormed=formJSONRequest(dialogflowQuery);
            Gson gson = new Gson();
            DialogFlowStruct objectRequest = gson.fromJson(jsonFormed, DialogFlowStruct.class);
       
        
            FachadaBD fachada = FachadaBD.getInstancia();
            String lang = objectRequest.getLanguageCode();
            System.out.println("LANG:"+lang);
            fachada.setLang(lang);
             
            respuesta= getIntentResponse(objectRequest);
            
        }catch(Exception excp){
            excp.printStackTrace();
            respuesta="No le he entendido, reformule su pregunta por favor.";
            
        }
        
        try{
            sendResponseToDialogFlow(response,respuesta);
        }catch(IOException ioExcept){
        
        } 
    }
    /**
     * Metodo formJSONRequest, dado un String con la respuesta ofrecida por DialogFlow
     * devuelve un String con un JSON con la estructura requerida para ser eficientemente
     * parseada.
     * 
     * @param dialogFlowQuery   Un String representando la respuesta obtenida de DialogFlow
     * @return String con JSON con los campos básicos para el parseo
     */
    private String formJSONRequest(String dialogFlowQuery){
        String jsonFormed="";
        //campos principales
        String fieldResponseId = "\"responseId\":";
        String fieldQueryResult = "\"queryResult\": {";
        
        //campos de parametros
        String fieldQueryText = "\"queryText\":";
        String fieldParameters="\"parameters\": {";
        String fieldAllRequiredParamsPresent = "\"allRequiredParamsPresent\":";
        String fieldOutputContext = "\"outputContexts\": [";
        String fieldIntent = "\"intent\": {";
        String fieldIntentDetectionConfidence = "\"intentDetectionConfidence\":";
        String fieldLanguageCode = "\"languageCode\":";
        
        String substringFieldParameters="";
        
        boolean outputContextResponse = false;
        
        try{
            dialogFlowQuery=new String(dialogFlowQuery.getBytes("ISO-8859-1"), "UTF-8");
        }catch(Exception uEexcp){
           uEexcp.printStackTrace();
        }
        
        //existe un contexto del que sacar los parametros o no
        if(dialogFlowQuery.contains("outputContexts")){
            outputContextResponse=true;
            substringFieldParameters = fieldOutputContext;
        }else{
            substringFieldParameters = fieldParameters;
        }
        System.out.println(dialogFlowQuery);
        int begResponseID = dialogFlowQuery.indexOf(fieldResponseId);
        int endResponseID = dialogFlowQuery.indexOf(",",begResponseID);
        String responseID = dialogFlowQuery.substring(begResponseID,endResponseID);
        System.out.println("responseID:\n"+responseID);
         
        int begQueryResult = dialogFlowQuery.indexOf(fieldQueryResult);
        int endQueryResult = dialogFlowQuery.lastIndexOf("}");
        
        System.out.println("beg:\n"+begQueryResult+"\nend:"+endQueryResult);
        dialogFlowQuery = dialogFlowQuery.substring(begQueryResult,endQueryResult);
        System.out.println("QueryResult:\n"+dialogFlowQuery);
        
        int begQueryText = dialogFlowQuery.indexOf(fieldQueryText);
        int endQueryText = dialogFlowQuery.indexOf("\"",begQueryText+14);
        System.out.println("beg:\n"+begQueryText+"\nend:"+endQueryText+1);
        String queryText = dialogFlowQuery.substring(begQueryText,endQueryText+1);
        System.out.println("queryText:\n"+queryText);
        
        int begParameters = dialogFlowQuery.indexOf(substringFieldParameters);
        int endParameters = dialogFlowQuery.indexOf("}",begParameters);
        String paramSection = dialogFlowQuery.substring(begParameters,endParameters+1);
        if(outputContextResponse){
            begParameters = paramSection.indexOf(fieldParameters);
            endParameters = paramSection.indexOf("}",begParameters);
            try{
                paramSection = paramSection.substring(begParameters,endParameters+1);
            }catch(Exception excpt){
                excpt.printStackTrace();
                paramSection="\"no-input\": 0.0";
            }
        }
        while(paramSection.contains("]")){
            paramSection = paramSection.replace("]", "");
        }
        while(paramSection.contains("[")){
            paramSection = paramSection.replace("[", "");
        }
        System.out.println("beg:\n"+begParameters+"\nend:"+endParameters);
        System.out.println("paramSection:\n"+paramSection);
        
        int begAllParametersPresent = dialogFlowQuery.indexOf(fieldAllRequiredParamsPresent);
        int endAllParametersPresent = dialogFlowQuery.indexOf(",",begAllParametersPresent);
        String allParametersPresent = dialogFlowQuery.substring(begAllParametersPresent,endAllParametersPresent);
        System.out.println("beg:\n"+begAllParametersPresent+"\nend:"+endAllParametersPresent);
        System.out.println("AllRequiredParamsPresent:\n"+allParametersPresent);
        
        int begIntent = dialogFlowQuery.indexOf(fieldIntent);
        int endIntent = dialogFlowQuery.indexOf("}",begIntent);
        String intent = dialogFlowQuery.substring(begIntent,endIntent+1);
        System.out.println("beg:\n"+begIntent+"\nend:"+endIntent);
        System.out.println("Intent:\n"+intent);
        
        int begIntentDetectionConfidence = dialogFlowQuery.indexOf(fieldIntentDetectionConfidence);
        int endIntentDetectionConfidence = dialogFlowQuery.indexOf(",",begIntentDetectionConfidence);
        String intentDetectionConfidence = dialogFlowQuery.substring(begIntentDetectionConfidence,endIntentDetectionConfidence);
        System.out.println("beg:\n"+begIntentDetectionConfidence+"\nend:"+endIntentDetectionConfidence);
        System.out.println("intentDetectionConfidence:\n"+intentDetectionConfidence);
        
        int begLanguageCode = dialogFlowQuery.indexOf(fieldLanguageCode);
        int endLanguageCode = dialogFlowQuery.indexOf("\n",begLanguageCode);
        String languageCode = dialogFlowQuery.substring(begLanguageCode,endLanguageCode);
        if(languageCode.contains(",")){
            languageCode=languageCode.substring(0,languageCode.indexOf(","));
        }
        System.out.println("beg:\n"+begLanguageCode+"\nend:"+endLanguageCode);
        System.out.println("languageCode:\n"+languageCode);
        
        jsonFormed = "{"+responseID+",\n"+queryText+",\n"+paramSection+",\n"+allParametersPresent+",\n"+intent+",\n"+intentDetectionConfidence+",\n"+languageCode+"\n}";
        
        System.out.println("JSON:\n"+jsonFormed);
        return jsonFormed;
    }
 
    /**
     * Metodo getIntentResponse, dada una estructura de datos de DialogFlow parseada
     * devuelve la respuesta al intent percibido por DialogFlow.
     * 
     * @param objectRequest objeto DialogFlowStruct 
     * @return String con el nombre de intent identificado
     */
     private String getIntentResponse(DialogFlowStruct objectRequest) {
        logica = new Presentador();
        String response=logica.getResponseFromPresenter(objectRequest);
        return response;
    }
    
     
    /**
     * Metodo sendResponseToDialogFlow, devuelve un JSON con la respuesta procesada a DialogFlow.
     * 
     * @param response objeto HttpServletResponse
     * @param respuesta String con la respeusta
     * @throws IOException si el objeto response no es adecuado para la escritura
     */ 
    private void sendResponseToDialogFlow(HttpServletResponse response,String respuesta) throws IOException {
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("{\n" +
            "  \"fulfillmentMessages\": [\n" +
            "    {\n" +
            "      \"text\": {\n" +
            "        \"text\": [\n" +
            "          \""+respuesta+"\"\n" +
            "        ]\n" +
            "      }\n" +
            "    }\n" +
            "  ]\n" +
            "}");   
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
